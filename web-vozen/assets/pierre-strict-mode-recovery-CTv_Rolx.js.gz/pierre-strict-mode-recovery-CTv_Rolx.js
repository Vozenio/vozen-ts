import{o as e}from"./rolldown-runtime-C0FnF6B9.js";import{t}from"./react-C21x__mS.js";import{t as n}from"./jsx-runtime-BdxMnOeJ.js";import{s as r}from"./use-media-query-CQCemZ5B.js";import{cn as i}from"./workspace-checkout-display-Cdwe9Mur.js";import{D as a,L as o,O as s,b as c,h as l,k as u,l as d,x as f,y as p,z as m}from"./cleanLastNewline-Cc4xc9M-.js";import{C as h,U as g,et as _,h as v,m as y,nt as b,p as x,q as ee}from"./computeVirtualFileMetrics-xcXBef4Y.js";var S=e(t(),1);function te(e){let t=(0,S.useRef)(e);return(0,S.useInsertionEffect)(()=>void(t.current=e)),(0,S.useCallback)((...e)=>t.current(...e),[])}var C=e(n(),1),ne=(0,S.createContext)(void 0);function re(){return(0,S.useContext)(ne)}var ie={position:`absolute`,top:0,bottom:0,textAlign:`center`,whiteSpace:`normal`,touchAction:`none`},ae={display:`contents`};function oe(){return null}function se(e){return`annotation-${`side`in e?`${e.side}-`:``}${e.lineNumber}`}var w=(0,S.createContext)(void 0);function T(e,t,n){if(e===t||e==null||t==null)return e===t;let r=new Set(n),i=Object.keys(e),a=new Set(Object.keys(t));for(let n of i)if(a.delete(n),!r.has(n)&&(!(n in t)||e[n]!==t[n]))return!1;for(let e of Array.from(a))if(!r.has(e))return!1;return!0}function ce(e,t){let n=e?.theme??l,r=t?.theme??l,i=E(e),a=E(t);return b(n,r)&&T(e,t,[`theme`,`parseDiffOptions`])&&T(i,a)}function E(e){if(e!=null&&`parseDiffOptions`in e)return e.parseDiffOptions}var D=new Set,O=null;function k(e){D.add(e),O??=requestAnimationFrame(ue)}function A(e){D.delete(e)&&D.size===0&&O!=null&&(cancelAnimationFrame(O),O=null)}function le(){D.clear(),O!=null&&typeof cancelAnimationFrame==`function`&&cancelAnimationFrame(O),O=null}function ue(e){let t=new Set(D);D.clear();for(let n of t)try{n(e)}catch(e){console.error(e)}O=D.size>0?requestAnimationFrame(ue):null}function j(e,t){return e?.start===t?.start&&e?.end===t?.end&&e?.side===t?.side&&e?.endSide===t?.endSide}function M({scrollTop:e,scrollHeight:t,height:n,fitPerfectly:r=!1,fitPerfectlyOverscroll:i=0,overscrollSize:a}){let o=n+a*2,s=r?n+i*2:o;if(t=Math.max(t,s),o>=t||r){let n=Math.max(e-i,0),r=Math.min(e+s,t);return{top:n,bottom:Math.max(r,n)}}let c=e+n/2-o/2,l=c+o;return c<0&&(c=0),l>t&&(l=t),c=Math.floor(Math.max(c,0)),{top:c,bottom:Math.ceil(Math.max(Math.min(l,t),c))}}function de(e){if(typeof HTMLStyleElement<`u`&&e instanceof HTMLStyleElement)return!0;let t=e.tagName??e.nodeName;return typeof t==`string`&&t.toLowerCase()===`style`}var fe=`-1,-1`;function pe(e){return e?.some(e=>e.lineNumber===0)??!1}function me(e){let t=e[0];return t!=null&&t.length>0?t:void 0}function he(e){return e.startingLine===0&&e.totalLines>0}function ge(e,t){return e.lineNumber===t.lineNumber&&e.side===t.side}function N(){return x({tagName:`button`,properties:{"data-utility-button":``,type:`button`},children:[y({name:`diffs-icon-plus`,properties:{"data-icon":``}})]})}function P(e){for(let t of e)if(t instanceof HTMLElement&&(t.hasAttribute(`data-utility-button`)||t.hasAttribute(`data-gutter-utility-slot`)||t.getAttribute(`slot`)===`gutter-utility-slot`||t.getAttribute(`name`)===`gutter-utility-slot`))return!0;return!1}var _e=class{mode;options;hoveredLine;hoveredToken;pre;gutterUtilityLine;gutterUtilityContainer;gutterUtilityButton;gutterUtilitySlot;interactiveLinesAttr=!1;interactiveLineNumbersAttr=!1;hasPointerListeners=!1;hasDocumentPointerListeners=!1;selectedRange=null;selectedRangeHighlightSide;selectedRangeLineNumberOnly=!1;editorActiveLine=null;editorActiveLineSide;editorLineNumberOnly=!1;proposedSelectedRange;renderedSelectedLinesState;renderedEditorActiveLineState;selectionAnchor;pointerSession={mode:`idle`};constructor(e,t){this.mode=e,this.options=t}setOptions(e){this.options=e}cleanUp(){this.pre?.removeEventListener(`click`,this.handlePointerClick),this.pre?.removeEventListener(`pointerdown`,this.handlePointerDown),this.pre?.removeEventListener(`pointermove`,this.handlePointerMove),this.pre?.removeEventListener(`pointerleave`,this.handlePointerLeave),this.pre?.removeAttribute(`data-interactive-lines`),this.pre?.removeAttribute(`data-interactive-line-numbers`),this.pre=void 0,this.gutterUtilityContainer?.remove(),this.gutterUtilityLine=void 0,this.gutterUtilityContainer=void 0,this.gutterUtilityButton=void 0,this.gutterUtilitySlot=void 0,this.clearHoveredLine(),this.clearHoveredToken(),this.detachDocumentPointerListeners(),this.clearPointerSession(),A(this.renderSelection),this.interactiveLinesAttr=!1,this.interactiveLineNumbersAttr=!1,this.hasPointerListeners=!1,this.setSelectionDirty()}setup(e){this.setSelectionDirty();let{usesCustomGutterUtility:t=!1,enableGutterUtility:n=!1}=this.options;this.pre!==e&&(this.cleanUp(),this.pre=e),n?this.ensureGutterUtilityNode(t):this.gutterUtilityContainer!=null&&(this.gutterUtilityContainer.remove(),this.gutterUtilityLine=void 0,this.gutterUtilityContainer=void 0,this.gutterUtilityButton=void 0,this.gutterUtilitySlot=void 0,this.pointerSession.mode===`gutterSelecting`&&(this.clearPointerSession(),this.detachDocumentPointerListeners())),this.syncPointerListeners(e),this.updateInteractiveLineAttributes(),this.renderSelection(),this.placeUtility()}setSelectionDirty(){this.renderedSelectedLinesState=void 0,this.renderedEditorActiveLineState=void 0}isSelectionDirty(){return this.renderedSelectedLinesState===void 0||this.renderedEditorActiveLineState===void 0}setSelection(e,t){let n=!(e===this.selectedRange||j(e??void 0,this.selectedRange??void 0)),r=t?.lineNumberOnly??!1,i=t?.activeLineSide!==this.selectedRangeHighlightSide||r!==this.selectedRangeLineNumberOnly;!this.isSelectionDirty()&&!n&&!i||(this.proposedSelectedRange=void 0,this.selectedRange=e,this.selectedRangeHighlightSide=t?.activeLineSide,this.selectedRangeLineNumberOnly=r,this.renderSelection(),this.placeUtility(),n&&t?.notify!==!1&&this.notifySelectionCommitted(e))}setEditorActiveLine(e,{lineNumberOnly:t=!1,side:n}={}){let r=e!==this.editorActiveLine,i=n!==this.editorActiveLineSide||t!==this.editorLineNumberOnly;!this.isSelectionDirty()&&!r&&!i||(this.editorActiveLine=e,this.editorActiveLineSide=n,this.editorLineNumberOnly=t,this.renderSelection())}getSelection(){return this.selectedRange}getHoveredLine=()=>{let e=this.gutterUtilityLine??this.hoveredLine;if(e!=null){if(this.mode===`diff`&&e.type===`diff-line`)return{lineNumber:e.lineNumber,side:e.annotationSide};if(this.mode===`file`&&e.type===`line`)return{lineNumber:e.lineNumber}}};handlePointerClick=e=>{let{onHunkExpand:t,onLineClick:n,onLineNumberClick:r,onTokenClick:i,onMergeConflictActionClick:a}=this.options;(t!=null||n!=null||r!=null||a!=null||i!=null)&&(this.options.onGutterUtilityClick!=null&&P(e.composedPath())||(W(this.options.__debugPointerEvents,`click`,`FileDiff.DEBUG.handlePointerClick:`,e),this.handlePointerEvent({eventType:`click`,event:e})))};handlePointerMove=e=>{if(e.pointerType!==`mouse`)return;let{lineHoverHighlight:t=`disabled`,onLineEnter:n,onLineLeave:r,onTokenEnter:i,onTokenLeave:a,enableGutterUtility:o=!1}=this.options;t===`disabled`&&!o&&n==null&&r==null&&i==null&&a==null||(W(this.options.__debugPointerEvents,`move`,`FileDiff.DEBUG.handlePointerMove:`,e),this.handlePointerEvent({eventType:`move`,event:e}))};handlePointerLeave=e=>{let{__debugPointerEvents:t}=this.options;if(W(t,`move`,`FileDiff.DEBUG.handlePointerLeave: no event`),this.hoveredLine==null&&this.hoveredToken==null){W(t,`move`,`FileDiff.DEBUG.handlePointerLeave: returned early, no hovered line or token`);return}this.hoveredToken!=null&&(this.options.onTokenLeave?.(this.hoveredToken,e),this.clearHoveredToken()),this.hoveredLine!=null&&(this.options.onLineLeave?.({...this.hoveredLine,event:e}),this.clearHoveredLine()),this.placeUtility()};handlePointerEvent({eventType:e,event:t}){let{__debugPointerEvents:n}=this.options,r=t.composedPath();W(n,e,`FileDiff.DEBUG.handlePointerEvent:`,{eventType:e,composedPath:r});let i=this.resolvePointerTarget(r);W(n,e,`FileDiff.DEBUG.handlePointerEvent: resolvePointerTarget result:`,i);let{onLineClick:a,onLineNumberClick:o,onLineEnter:s,onLineLeave:c,onTokenClick:l,onTokenEnter:u,onTokenLeave:d,onHunkExpand:f,onMergeConflictActionClick:p}=this.options;switch(e){case`move`:{let e=L(i)&&this.hoveredLine?.lineElement===i.lineElement;I(i)&&this.hoveredToken?.tokenElement===i.tokenElement||(this.hoveredToken!=null&&(d?.(this.hoveredToken,t),this.clearHoveredToken()),I(i)&&(this.setHoveredToken(this.toTokenEventBaseProps(i)),u?.(this.hoveredToken,t))),e||(this.hoveredLine!=null&&(c?.({...this.hoveredLine,event:t}),this.clearHoveredLine()),L(i)?(this.setHoveredLine(this.toEventBaseProps(i)),this.placeUtility(),s?.({...this.hoveredLine,event:t})):this.placeUtility());break}case`click`:{if(i==null)break;if(xe(i)&&p!=null){p(i);break}if(be(i)&&f!=null){f(i.hunkIndex,i.all||t.shiftKey?`both`:i.direction,i.all||t.shiftKey?1/0:void 0);break}if(!L(i))break;I(i)&&l!=null&&l(this.toTokenEventBaseProps(i),t);let e=this.toEventBaseProps(i);o!=null&&i.numberColumn?o({...e,event:t}):a?.({...e,event:t});break}}}syncPointerListeners(e){let{__debugPointerEvents:t,lineHoverHighlight:n=`disabled`,onLineClick:r,onLineNumberClick:i,onLineEnter:a,onLineLeave:o,onTokenClick:s,onTokenEnter:c,onTokenLeave:l,onHunkExpand:u,onMergeConflictActionClick:d,enableGutterUtility:f=!1,enableLineSelection:p=!1,onGutterUtilityClick:m}=this.options,h=m!=null,g=n!==`disabled`||r!=null||i!=null||a!=null||o!=null||s!=null||c!=null||l!=null||u!=null||d!=null||f||p||h;g&&!this.hasPointerListeners?(e.addEventListener(`click`,this.handlePointerClick),e.addEventListener(`pointerdown`,this.handlePointerDown),e.addEventListener(`pointermove`,this.handlePointerMove),e.addEventListener(`pointerleave`,this.handlePointerLeave),this.hasPointerListeners=!0,W(t,`click`,`FileDiff.DEBUG.attachEventListeners: Attaching click events for:`,(()=>{let e=[];return(t===`both`||t===`click`)&&(r!=null&&e.push(`onLineClick`),i!=null&&e.push(`onLineNumberClick`),u!=null&&e.push(`expandable hunk separators`),d!=null&&e.push(`merge conflict actions`)),e})()),W(t,`move`,`FileDiff.DEBUG.attachEventListeners: Attaching pointer move event`),W(t,`move`,`FileDiff.DEBUG.attachEventListeners: Attaching pointer leave event`)):!g&&this.hasPointerListeners&&(e.removeEventListener(`click`,this.handlePointerClick),e.removeEventListener(`pointerdown`,this.handlePointerDown),e.removeEventListener(`pointermove`,this.handlePointerMove),e.removeEventListener(`pointerleave`,this.handlePointerLeave),this.hasPointerListeners=!1);let _=this.pointerSession.mode===`selecting`||this.pointerSession.mode===`pendingSingleLineUnselect`,v=this.pointerSession.mode===`gutterSelecting`;(!p&&_||!h&&v)&&(this.clearPointerSession(),this.detachDocumentPointerListeners(),this.selectionAnchor=void 0,this.clearPendingSingleLineState())}updateInteractiveLineAttributes(){if(this.pre==null)return;let{onLineClick:e,onLineNumberClick:t,enableLineSelection:n=!1}=this.options,r=e!=null,i=t!=null||n;r&&!this.interactiveLinesAttr?(this.pre.setAttribute(`data-interactive-lines`,``),this.interactiveLinesAttr=!0):!r&&this.interactiveLinesAttr&&(this.pre.removeAttribute(`data-interactive-lines`),this.interactiveLinesAttr=!1),i&&!this.interactiveLineNumbersAttr?(this.pre.setAttribute(`data-interactive-line-numbers`,``),this.interactiveLineNumbersAttr=!0):!i&&this.interactiveLineNumbersAttr&&(this.pre.removeAttribute(`data-interactive-line-numbers`),this.interactiveLineNumbersAttr=!1)}handlePointerDown=e=>{if(e.pointerType===`mouse`&&e.button!==0||this.pre==null||this.pointerSession.mode!==`idle`)return;let t=e.composedPath();P(t)&&this.options.onGutterUtilityClick!=null?this.startGutterSelectionFromPointerDown(e):(e.pointerType!==`mouse`&&this.revealUtilityFromGutterPath(t),this.startLineSelectionFromPointerDown(e))};startLineSelectionFromPointerDown(e){let{enableLineSelection:t=!1}=this.options;if(!t)return;let n=this.resolveSelectionInfo(e,{source:`event-path`,requireNumberColumn:!0});if(n==null)return;let{pre:r}=this;if(r==null)return;let{lineNumber:i,eventSide:a,lineIndex:o}=n;if(e.shiftKey&&this.selectedRange!=null){let t=this.getIndexesFromSelection(this.selectedRange,r.getAttribute(`data-diff-type`)===`split`);if(t==null)return;let n=t.start<=t.end?o>=t.start:o<=t.end;this.selectionAnchor={lineNumber:n?this.selectedRange.start:this.selectedRange.end,side:n?this.selectedRange.side:this.selectedRange.endSide??this.selectedRange.side},this.updateSelection(i,a,!1),this.notifySelectionStart(this.getCurrentSelectionRange()),this.pointerSession={mode:`selecting`,pointerId:e.pointerId},this.attachDocumentPointerListeners();return}if(this.selectedRange?.start===i&&this.selectedRange?.end===i){let t={lineNumber:i,side:a};this.selectionAnchor=t,this.pointerSession={mode:`pendingSingleLineUnselect`,pointerId:e.pointerId,anchor:t,pending:t},this.attachDocumentPointerListeners();return}this.options.controlledSelection===!0?this.proposedSelectedRange=null:this.selectedRange=null,this.placeUtility(),this.selectionAnchor={lineNumber:i,side:a},this.updateSelection(i,a,!1),this.notifySelectionStart(this.getCurrentSelectionRange()),this.pointerSession={mode:`selecting`,pointerId:e.pointerId},this.attachDocumentPointerListeners()}startGutterSelectionFromPointerDown(e){let{onGutterUtilityClick:t}=this.options;if(t==null)return;let n=this.currentSelectionEnds(),r=n?.bottom??this.resolveSelectionPoint(e,{source:`event-path`,excludeUtility:!1}),i=n?.top??r;r!=null&&i!=null&&(e.preventDefault(),e.stopPropagation(),this.pointerSession={mode:`gutterSelecting`,pointerId:e.pointerId,anchor:i,current:r},this.selectionAnchor={lineNumber:i.lineNumber,side:i.side},this.updateSelection(r.lineNumber,r.side,!1),this.notifySelectionStart(this.getCurrentSelectionRange()),this.attachDocumentPointerListeners())}handleDocumentPointerMove=e=>{switch(this.pointerSession.mode){case`idle`:return;case`gutterSelecting`:{if(e.pointerId!==this.pointerSession.pointerId)return;e.preventDefault();let t=this.resolveSelectionPoint(e,{source:`coordinates-first`});if(t==null)return;this.pointerSession.current=t,this.updateSelection(t.lineNumber,t.side);return}case`selecting`:{if(e.pointerId!==this.pointerSession.pointerId)return;e.preventDefault();let t=this.resolveSelectionInfo(e,{source:`coordinates-first`,requireNumberColumn:!1});if(t==null||this.selectionAnchor==null)return;this.updateSelection(t.lineNumber,t.eventSide);return}case`pendingSingleLineUnselect`:{if(e.pointerId!==this.pointerSession.pointerId)return;e.preventDefault();let t=this.resolveSelectionInfo(e,{source:`coordinates-first`,requireNumberColumn:!1});if(t==null||this.selectionAnchor==null)return;let n={lineNumber:t.lineNumber,side:t.eventSide};if(ge(this.pointerSession.pending,n))return;this.updateSelection(t.lineNumber,t.eventSide,!1),this.notifySelectionStart(this.getCurrentSelectionRange()),this.notifySelectionChangeDelta(),this.pointerSession={mode:`selecting`,pointerId:e.pointerId};return}}};handleDocumentPointerUp=e=>{let{onGutterUtilityClick:t}=this.options;switch(this.pointerSession.mode){case`idle`:return;case`gutterSelecting`:{let{pointerSession:n}=this;if(e.pointerId!==n.pointerId)return;e.preventDefault();let r=this.resolveSelectionPoint(e,{source:`coordinates-first`});r!=null&&(n.current=r,this.updateSelection(r.lineNumber,r.side));let i=this.buildSelectedLineRange(n.anchor,n.current);t?.({...i}),this.selectionAnchor=void 0,this.notifySelectionEnd(i),this.notifySelectionCommitted(i),this.clearProposedSelection(),this.clearPointerSession(),this.detachDocumentPointerListeners();return}case`pendingSingleLineUnselect`:if(e.pointerId!==this.pointerSession.pointerId)return;e.preventDefault(),this.updateSelection(null,void 0,!1),this.selectionAnchor=void 0,this.clearPendingSingleLineState(),this.detachDocumentPointerListeners(),this.notifySelectionEnd(this.getCurrentSelectionRange()),this.notifySelectionCommitted(this.getCurrentSelectionRange()),this.clearProposedSelection();return;case`selecting`:if(e.pointerId!==this.pointerSession.pointerId)return;e.preventDefault(),this.selectionAnchor=void 0,this.detachDocumentPointerListeners(),this.clearPointerSession(),this.notifySelectionEnd(this.getCurrentSelectionRange()),this.notifySelectionCommitted(this.getCurrentSelectionRange()),this.clearProposedSelection()}};handleDocumentPointerCancel=e=>{switch(this.pointerSession.mode){case`idle`:return;case`gutterSelecting`:case`selecting`:case`pendingSingleLineUnselect`:if(`pointerId`in this.pointerSession&&e.pointerId!==this.pointerSession.pointerId)return;this.selectionAnchor=void 0,this.clearProposedSelection(),this.clearPendingSingleLineState(),this.clearPointerSession(),this.detachDocumentPointerListeners()}};clearHoveredLine(){this.hoveredLine!=null&&(this.hoveredLine.lineElement.removeAttribute(`data-hovered`),this.hoveredLine.numberElement.removeAttribute(`data-hovered`),this.hoveredLine=void 0)}setHoveredLine(e){let{lineHoverHighlight:t=`disabled`}=this.options;this.hoveredLine!=null&&this.clearHoveredLine(),this.hoveredLine=e,t!==`disabled`&&((t===`both`||t===`line`)&&this.hoveredLine.lineElement.setAttribute(`data-hovered`,``),(t===`both`||t===`number`)&&this.hoveredLine.numberElement.setAttribute(`data-hovered`,``))}clearHoveredToken(){this.hoveredToken!=null&&(this.hoveredToken=void 0)}setHoveredToken(e){this.hoveredToken!=null&&this.clearHoveredToken(),this.hoveredToken=e}ensureGutterUtilityNode(e){if(this.gutterUtilityContainer??(this.gutterUtilityContainer=document.createElement(`div`),this.gutterUtilityContainer.setAttribute(`data-gutter-utility-slot`,``)),e)this.gutterUtilityButton!=null&&(this.gutterUtilityButton.remove(),this.gutterUtilityButton=void 0),this.gutterUtilitySlot??(this.gutterUtilitySlot=document.createElement(`slot`),this.gutterUtilitySlot.name=`gutter-utility-slot`),this.gutterUtilitySlot.parentNode!==this.gutterUtilityContainer&&this.gutterUtilityContainer.replaceChildren(this.gutterUtilitySlot);else{if(this.gutterUtilitySlot?.remove(),this.gutterUtilitySlot=void 0,this.gutterUtilityButton==null){let e=document.createElement(`div`);e.innerHTML=g(N());let t=e.firstElementChild;if(!(t instanceof HTMLButtonElement))throw Error(`InteractionManager.ensureGutterUtilityNode: Node element should be a button`);t.remove(),this.gutterUtilityButton=t}this.gutterUtilityButton.parentNode!==this.gutterUtilityContainer&&this.gutterUtilityContainer.replaceChildren(this.gutterUtilityButton)}}revealUtilityFromGutterPath(e){if(this.placeUtilityFromSelection())return;let t=this.resolvePointerTarget(e);F(t)&&t.numberColumn&&this.showUtilityOnLine(this.toEventBaseProps(t))}placeUtility(){if(!this.placeUtilityFromSelection()){if(this.hoveredLine!=null){this.showUtilityOnLine(this.hoveredLine);return}this.hideUtility()}}placeUtilityFromSelection(){let e=this.currentSelectionEnds();if(e==null)return!1;let t=this.targetForSelectionPoint(e.bottom);return t==null?this.hideUtility():this.showUtilityOnLine(this.toEventBaseProps(t)),!0}showUtilityOnLine(e){this.gutterUtilityContainer!=null&&(this.gutterUtilityLine=e,e.numberElement.appendChild(this.gutterUtilityContainer))}hideUtility(){this.gutterUtilityContainer?.remove(),this.gutterUtilityLine=void 0}currentSelectionEnds(){let e=this.getCurrentSelectionRange();return e==null?void 0:this.selectionEnds(e)}selectionEnds(e){let t={lineNumber:e.start,side:e.side},n={lineNumber:e.end,side:e.endSide??e.side},r=this.selectionPointRowIndex(t),i=this.selectionPointRowIndex(n);if(r!=null&&i!=null)return r>i?{top:n,bottom:t}:{top:t,bottom:n}}selectionPointRowIndex(e){let t=this.getLineIndex(e.lineNumber,e.side);if(t!=null)return this.isSplitDiff()?t[1]:t[0]}targetForSelectionPoint(e){if(this.pre==null)return;let t=this.getLineIndex(e.lineNumber,e.side);if(t==null)return;let n=this.mode===`diff`?`${t[0]},${t[1]}`:`${t[0]}`,r=this.pre.querySelectorAll(`[data-column-number="${e.lineNumber}"][data-line-index="${n}"]`);for(let t of r){if(!(t instanceof HTMLElement))continue;let n=this.resolvePointerTarget(z(t));if(F(n)&&(this.mode!==`diff`||e.side==null||n.side===e.side))return n}}attachDocumentPointerListeners(){this.hasDocumentPointerListeners||=(document.addEventListener(`pointermove`,this.handleDocumentPointerMove),document.addEventListener(`pointerup`,this.handleDocumentPointerUp),document.addEventListener(`pointercancel`,this.handleDocumentPointerCancel),!0)}detachDocumentPointerListeners(){this.hasDocumentPointerListeners&&=(document.removeEventListener(`pointermove`,this.handleDocumentPointerMove),document.removeEventListener(`pointerup`,this.handleDocumentPointerUp),document.removeEventListener(`pointercancel`,this.handleDocumentPointerCancel),!1)}clearPointerSession(){this.pointerSession={mode:`idle`}}clearPendingSingleLineState(){this.pointerSession.mode===`pendingSingleLineUnselect`&&(this.pointerSession={mode:`idle`})}selectionInfoFromPath(e,t){let n=this.resolvePointerTarget(e);if(F(n)&&!(t&&!n.numberColumn)&&n.splitLineIndex!=null)return{lineIndex:n.splitLineIndex,lineNumber:n.lineNumber,eventSide:this.mode===`diff`?n.side:void 0}}resolveSelectionInfo(e,t){let n=this.resolveSelectionPath(e,t);return n==null?void 0:this.selectionInfoFromPath(n,t.requireNumberColumn)}selectionPointFromPath(e){let t=this.resolvePointerTarget(e);if(F(t))return{lineNumber:t.lineNumber,side:this.mode===`diff`?t.side:void 0}}resolveSelectionPoint(e,t){let n=this.resolveSelectionPath(e,t);return n==null?void 0:this.selectionPointFromPath(n)}resolveSelectionPath(e,t){let n=t.excludeUtility!==!1;switch(t.source){case`event-path`:return this.pathFromEventPath(e.composedPath(),n);case`coordinates-first`:{let t=this.pathFromCoordinates(e,n);return t===void 0?this.pathFromEventPath(e.composedPath(),n):t??void 0}}}pathFromCoordinates(e,t){let n=this.hitTest(e);if(n!==void 0)return n===null?null:this.pathFromElement(n,t)??null}pathFromEventPath(e,t){if(!(t&&P(e))){for(let n of e)if(n instanceof Element)return this.pathFromElement(n,t)}}pathFromElement(e,t){let n=z(e);if(t&&P(n))return;let r=Ce(e);return r==null?this.pathFromAnnotationSlot(e):z(r)}pathFromAnnotationSlot(e){let t=Te(we(e));if(t==null)return;let n=this.targetForSelectionPoint(t);return n==null?void 0:z(n.lineElement)}hitTest(e){if(!Number.isFinite(e.clientX)||!Number.isFinite(e.clientY))return;let t=this.pre?.getRootNode(),n=B(t)?t:B(document)?document:void 0;if(n!=null)return n.elementFromPoint(e.clientX,e.clientY)}getLineIndex(e,t){let{getLineIndex:n}=this.options;return n==null?[e-1,e-1]:n(e,t)}getCurrentSelectionRange(){return this.proposedSelectedRange===void 0?this.selectedRange:this.proposedSelectedRange}clearProposedSelection(){this.proposedSelectedRange=void 0}updateSelection(e,t,n=!0){let r=this.getCurrentSelectionRange(),i;if(e==null)i=null;else{let n=this.selectionAnchor?.side??t,r=this.selectionAnchor?.lineNumber??e;i=this.buildSelectionRange(r,e,n,t)}j(r??void 0,i??void 0)||(this.selectedRangeHighlightSide=void 0,this.selectedRangeLineNumberOnly=!1,this.options.controlledSelection===!0?this.proposedSelectedRange=i:(this.selectedRange=i,k(this.renderSelection)),this.placeUtility(),n&&this.notifySelectionChangeDelta())}getIndexesFromSelection(e,t){if(this.pre==null)return;let n=this.getLineIndex(e.start,e.side),r=this.getLineIndex(e.end,e.endSide??e.side);return n!=null&&r!=null?{start:t?n[1]:n[0],end:t?r[1]:r[0]}:void 0}getSelectionRenderState(){return{selectedLines:{range:this.selectedRange,highlightSide:this.selectedRangeHighlightSide,lineNumberOnly:this.selectedRangeLineNumberOnly},editorActiveLine:{range:this.editorActiveLine==null?null:{start:this.editorActiveLine,end:this.editorActiveLine,side:this.editorActiveLineSide},highlightSide:this.editorActiveLineSide,lineNumberOnly:this.editorLineNumberOnly}}}resolveLineRenderRange(e,t,n){if(e.range==null)return;let r=this.getIndexesFromSelection(e.range,t);if(r==null)throw console.error({rowRange:r,range:e.range}),Error(`InteractionManager.renderSelection: No valid ${n} rowRange`);return r}getLineRenderColumns(e,t,n,r){if(this.pre==null||t==null&&r==null)return[];let{children:i}=this.pre;if(i.length>2)throw console.error(i),Error(`InteractionManager.renderSelection: Somehow there are more than 2 code elements...`);let a=[];for(let o of i){let i=o.hasAttribute(`data-deletions`)?`deletions`:o.hasAttribute(`data-additions`)?`additions`:void 0,s=e!=null&&t!=null&&(e.highlightSide==null||i==null||e.highlightSide===i),c=n!=null&&r!=null&&(n.highlightSide==null||i==null||n.highlightSide===i);if(!s&&!c)continue;let[l,u]=o.children;if(!(l instanceof HTMLElement)||!(u instanceof HTMLElement))throw Error(`InteractionManager.renderSelection: missing gutter or content element`);if(u.children.length!==l.children.length)throw Error(`InteractionManager.renderSelection: gutter and content children dont match, something is wrong`);a.push({content:u,gutter:l,renderEditorActiveLine:c,renderSelectedLines:s})}return a}renderSelection=()=>{A(this.renderSelection);let e=this.getSelectionRenderState();if(this.pre==null)return;let{editorActiveLine:t,selectedLines:n}=e,r=!V(this.renderedSelectedLinesState,n),i=!V(this.renderedEditorActiveLineState,t);if(!r&&!i)return;r&&(this.renderedSelectedLinesState=void 0),i&&(this.renderedEditorActiveLineState=void 0);let a=this.pre.getAttribute(`data-diff-type`)===`split`,o=r?this.resolveLineRenderRange(n,a,`selected-lines`):void 0,s=i?this.resolveLineRenderRange(t,a,`editor-active-line`):void 0,c=this.getLineRenderColumns(r?n:void 0,o,i?t:void 0,s),l=n.range==null||c.some(e=>e.renderSelectedLines),u=t.range==null||c.some(e=>e.renderEditorActiveLine);if(r)for(let e of this.pre.querySelectorAll(`[data-selected-line]`))e.removeAttribute(`data-selected-line`);if(i)for(let e of this.pre.querySelectorAll(`[data-editor-active-line]`))e.removeAttribute(`data-editor-active-line`);let d=o==null?void 0:Math.min(o.start,o.end),f=o==null?void 0:Math.max(o.start,o.end),p=d===f,m=s?.start;for(let e of c){let{content:r,gutter:i,renderEditorActiveLine:o,renderSelectedLines:s}=e,c=Math.max(s?f??-1/0:-1/0,o?m??-1/0:-1/0),l=r.children.length;for(let e=0;e<l;e++){let l=r.children[e],u=i.children[e];if(!(l instanceof HTMLElement)||!(u instanceof HTMLElement))continue;let h=this.parseLineIndex(l,a);if((h??0)>c)break;if(h!=null){if(s&&d!=null&&f!=null&&h>=d&&h<=f){let e=p?`single`:h===d?`first`:h===f?`last`:``;u.setAttribute(`data-selected-line`,e),n.lineNumberOnly||(l.setAttribute(`data-selected-line`,e),u.nextSibling instanceof HTMLElement&&l.nextSibling instanceof HTMLElement&&(l.nextSibling.hasAttribute(`data-line-annotation`)||l.nextSibling.hasAttribute(`data-merge-conflict-actions`))&&(p?(e=`last`,l.setAttribute(`data-selected-line`,`first`)):h===d?e=``:h===f&&l.setAttribute(`data-selected-line`,``),l.nextSibling.setAttribute(`data-selected-line`,e),u.nextSibling.setAttribute(`data-selected-line`,e)))}o&&h===m&&(u.setAttribute(`data-editor-active-line`,``),t.lineNumberOnly||l.setAttribute(`data-editor-active-line`,``))}}}r&&l&&(this.renderedSelectedLinesState=n),i&&u&&(this.renderedEditorActiveLineState=t)};notifySelectionCommitted(e){this.options.onLineSelected?.(e)}notifySelectionChangeDelta(){this.options.onLineSelectionChange?.(this.getCurrentSelectionRange()??null)}notifySelectionStart(e){this.options.onLineSelectionStart?.(e)}notifySelectionEnd(e){this.options.onLineSelectionEnd?.(e)}toEventBaseProps(e){return this.mode===`file`?{type:`line`,lineElement:e.lineElement,lineNumber:e.lineNumber,numberColumn:e.numberColumn,numberElement:e.numberElement}:{type:`diff-line`,annotationSide:e.side,lineType:e.lineType,lineElement:e.lineElement,numberElement:e.numberElement,lineNumber:e.lineNumber,numberColumn:e.numberColumn}}toTokenEventBaseProps({lineCharEnd:e,lineCharStart:t,lineNumber:n,side:r,tokenElement:i,tokenText:a}){return this.mode===`file`?{type:`token`,lineCharEnd:e,lineCharStart:t,lineNumber:n,tokenElement:i,tokenText:a}:{type:`token`,lineCharEnd:e,lineCharStart:t,lineNumber:n,side:r,tokenElement:i,tokenText:a}}buildSelectedLineRange(e,t){return this.buildSelectionRange(e.lineNumber,t.lineNumber,e.side,t.side)}buildSelectionRange(e,t,n,r){return{start:e,end:t,...n==null?{}:{side:n},...n!==r&&r!=null?{endSide:r}:{}}}resolvePointerTarget(e){let t=!1,n,r,i,a,o,s,c,l,u,d;for(let f of e){if(!(f instanceof HTMLElement))continue;if(d==null&&f.hasAttribute(`data-merge-conflict-action`)){let e=f.getAttribute(`data-merge-conflict-action`)??void 0,t=f.getAttribute(`data-merge-conflict-conflict-index`)??void 0,n=t==null?NaN:Number.parseInt(t,10);Se(e)&&Number.isFinite(n)&&(d={kind:`merge-conflict-action`,resolution:e,conflictIndex:n})}if(s==null&&f.hasAttribute(`data-char`)){s=f;let e=f.getAttribute(`data-char`);if(e!=null){let t=Number.parseInt(e,10);if(!Number.isNaN(t)){let e=f.textContent??``,n=t+e.length;(e.trim()!==``||this.options.enableTokenInteractionsOnWhitespace===!0)&&(c={tokenElement:s,lineCharStart:t,lineCharEnd:n,tokenText:e});continue}}}let e=o==null?f.getAttribute(`data-column-number`)??void 0:void 0;if(e!=null){o=f,u=Number.parseInt(e,10),t=!0,n=U(f),a=f.getAttribute(`data-line-index`)??void 0;continue}let p=i==null?f.getAttribute(`data-line`)??void 0:void 0;if(p!=null){i=f,u=Number.parseInt(p,10),n=U(f),a=f.getAttribute(`data-line-index`)??void 0;continue}if(l==null&&(f.hasAttribute(`data-expand-button`)||f.hasAttribute(`data-unmodified-lines`))){l={hunkIndex:void 0,direction:f.hasAttribute(`data-expand-up`)?`up`:f.hasAttribute(`data-expand-down`)?`down`:`both`,all:f.hasAttribute(`data-expand-all-button`)};continue}let m=l==null?void 0:f.getAttribute(`data-expand-index`)??void 0;if(l!=null&&m!=null){let e=Number.parseInt(m,10);Number.isNaN(e)||(l.hunkIndex=e);continue}if(r==null&&f.hasAttribute(`data-code`)){r=f;break}}if(d!=null)return d;if(l?.hunkIndex!=null)return{type:`line-info`,hunkIndex:l.hunkIndex,direction:l.direction,all:l.all};if(i??=a==null?void 0:R(r,`[data-line][data-line-index="${a}"]`),o??=a==null?void 0:R(r,`[data-column-number][data-line-index="${a}"]`),r==null||i==null||o==null||n==null||u==null||Number.isNaN(u))return;let f=this.parseLineIndex(i,this.isSplitDiff());return c==null?this.mode===`file`?{kind:`line`,lineType:n,lineElement:i,lineNumber:u,numberColumn:t,numberElement:o,side:void 0,splitLineIndex:f}:{kind:`line`,lineType:n,lineElement:i,lineNumber:u,numberColumn:t,numberElement:o,side:H(n,r),splitLineIndex:f}:this.mode===`file`?{kind:`token`,lineType:n,lineElement:i,lineNumber:u,numberColumn:t,numberElement:o,side:void 0,splitLineIndex:f,...c}:{kind:`token`,lineType:n,lineElement:i,lineNumber:u,numberColumn:t,numberElement:o,side:H(n,r),splitLineIndex:f,...c}}isSplitDiff(){return this.pre?.getAttribute(`data-diff-type`)===`split`}parseLineIndex(e,t){let n=(e.getAttribute(`data-line-index`)??``).split(`,`).map(e=>Number.parseInt(e,10)).filter(e=>!Number.isNaN(e));if(t&&n.length===2)return n[1];if(!t)return n[0]}};function ve({enableTokenInteractionsOnWhitespace:e,enableGutterUtility:t,lineHoverHighlight:n,onGutterUtilityClick:r,onLineClick:i,onLineEnter:a,onLineLeave:o,onLineNumberClick:s,onTokenClick:c,onTokenEnter:l,onTokenLeave:u,renderGutterUtility:d,__debugPointerEvents:f,enableLineSelection:p,controlledSelection:m,onLineSelected:h,onLineSelectionStart:g,onLineSelectionChange:_,onLineSelectionEnd:v},y,b,x){return{enableTokenInteractionsOnWhitespace:e,enableGutterUtility:ye({enableGutterUtility:t,renderGutterUtility:d,onGutterUtilityClick:r}),usesCustomGutterUtility:d!=null,lineHoverHighlight:n,onGutterUtilityClick:r,onHunkExpand:y,onMergeConflictActionClick:x,onLineClick:i,onLineEnter:a,onLineLeave:o,onLineNumberClick:s,onTokenClick:c,onTokenEnter:l,onTokenLeave:u,__debugPointerEvents:f,enableLineSelection:p,controlledSelection:m,onLineSelected:h,onLineSelectionStart:g,onLineSelectionChange:_,onLineSelectionEnd:v,getLineIndex:b}}function ye({enableGutterUtility:e,renderGutterUtility:t,onGutterUtilityClick:n}){if(n!=null&&t!=null)throw Error(`Cannot use both 'onGutterUtilityClick' and 'renderGutterUtility'. Use only one gutter utility API.`);return e??!1}function F(e){return e!=null&&`kind`in e&&e.kind===`line`}function I(e){return e!=null&&`kind`in e&&e.kind===`token`}function L(e){return F(e)||I(e)}function be(e){return`type`in e&&e.type===`line-info`}function xe(e){return`kind`in e&&e.kind===`merge-conflict-action`}function Se(e){return e===`current`||e===`incoming`||e===`both`}function R(e,t){let n=e?.querySelector(t);return n instanceof HTMLElement?n:void 0}function z(e){let t=[],n=e;for(;n!=null;)t.push(n),n=n.parentNode;return t}function Ce(e){let t=e.closest(`[data-line], [data-column-number]`);if(t instanceof HTMLElement)return t;let n=e.closest(`[data-line-annotation], [data-gutter-buffer="annotation"]`);if(!(n instanceof HTMLElement))return;let r=n.previousElementSibling;return r instanceof HTMLElement&&(r.hasAttribute(`data-line`)||r.hasAttribute(`data-column-number`))?r:void 0}function we(e){let t=e.closest(`[slot^="annotation-"]`);if(t instanceof HTMLElement)return t.getAttribute(`slot`)??void 0;if(e instanceof HTMLElement){let t=e.getAttribute(`name`)??void 0;return t!=null&&t.startsWith(`annotation-`)?t:void 0}}function Te(e){if(e==null)return;let t=/^annotation-(?:(additions|deletions)-)?(\d+)$/.exec(e);if(t==null)return;let n=Number.parseInt(t[2],10);if(!(!Number.isFinite(n)||n<=0))return{lineNumber:n,side:t[1]}}function B(e){return e!=null&&typeof e.elementFromPoint==`function`}function Ee(e,t){return e===t||j(e??void 0,t??void 0)}function V(e,t){return e?.highlightSide===t.highlightSide&&e?.lineNumberOnly===t.lineNumberOnly&&Ee(e?.range??null,t.range)}function H(e,t){switch(e){case`change-deletion`:return`deletions`;case`change-addition`:return`additions`;default:return t.hasAttribute(`data-deletions`)?`deletions`:`additions`}}function U(e){let t=e.getAttribute(`data-line-type`);if(t!=null)switch(t){case`change-deletion`:case`change-addition`:case`context`:case`context-expanded`:return t;default:return}}function W(e=`none`,t,...n){switch(e){case`none`:return;case`both`:break;case`click`:if(t!==`click`)return;break;case`move`:if(t!==`move`)return}console.log(...n)}var De=class e{static resizeObserver;static managersByElement=new Map;static getResizeObserver(){let t=e.resizeObserver??new ResizeObserver(e.handleSharedResizeEntries);return e.resizeObserver=t,t}static handleSharedResizeEntries(t){let n=new Map;for(let r of t){let t=e.managersByElement.get(r.target);if(t==null)continue;let i=n.get(t);i==null?n.set(t,[r]):i.push(r)}for(let[e,t]of n)e.handleResizeEntries(t)}observedNodes=new Map;setup(e,{disableAnnotations:t,columnVariables:n=`apply`}){let r=new Set,i=n===`apply`,a=0,o=new Map(this.observedNodes);this.observedNodes.clear();for(let t of e.children){if(a===2)break;let e=(()=>{if(t instanceof HTMLElement&&t.tagName===`CODE`)return t})();if(e==null)continue;a++;let n=o.get(e);if(n!=null&&n.type!==`code`)throw Error(`ResizeManager.setup: somehow a code node is being used for an annotation, should be impossible`);let r=e.firstElementChild;r instanceof HTMLElement||(r=null),n==null?(n={type:`code`,codeElement:e,numberElement:r,codeWidth:`auto`,numberWidth:0,applyColumnVariables:i},this.observedNodes.set(e,n),this.observe(e),r!=null&&(this.observedNodes.set(r,n),this.observe(r))):(this.observedNodes.set(e,n),o.delete(e),n.numberElement===r?n.numberElement==null?n.numberWidth=0:(o.delete(n.numberElement),this.observedNodes.set(n.numberElement,n)):(n.numberElement!=null&&(this.unobserve(n.numberElement),o.delete(n.numberElement)),r!=null&&(this.observe(r),o.delete(r),this.observedNodes.set(r,n)),n.numberElement=r,n.numberWidth=0),Ae(n,i))}if(a>1&&!t){let t=e.querySelectorAll(`[data-line-annotation*=","]`),n=new Map;for(let e of t){if(!(e instanceof HTMLElement))continue;let t=e.getAttribute(`data-line-annotation`)??``;if(!/^-?\d+,-?\d+$/.test(t)){console.error(`DiffFileRenderer.setupResizeObserver: Invalid element or annotation`,{lineAnnotation:t,element:e});continue}let r=n.get(t);r??(r=[],n.set(t,r)),r.push(e)}for(let[e,t]of n){if(t.length!==2){console.error(`DiffFileRenderer.setupResizeObserver: Bad Pair`,e,t);continue}let[n,i]=t,a=n.firstElementChild,s=i.firstElementChild;if(!(n instanceof HTMLElement)||!(i instanceof HTMLElement)||!(a instanceof HTMLElement)||!(s instanceof HTMLElement))continue;let c=o.get(a);if(c!=null){this.observedNodes.set(a,c),this.observedNodes.set(s,c),o.delete(a),o.delete(s);continue}let l=a.getBoundingClientRect().height,u=s.getBoundingClientRect().height;c={type:`annotations`,column1:{container:n,child:a,childHeight:l},column2:{container:i,child:s,childHeight:u},currentHeight:`auto`},r.add({child1:a,child2:s,item:c,newHeight:Math.max(l,u)})}for(let e of r)this.applyNewHeight(e.item,e.newHeight),this.observedNodes.set(e.child1,e.item),this.observedNodes.set(e.child2,e.item),this.observe(e.child1),this.observe(e.child2);r.clear()}for(let[e,t]of o)this.unobserve(e),t.type===`code`?je(t):Me(t);o.clear()}cleanUp(){for(let e of this.observedNodes.keys())this.unobserve(e);this.observedNodes.clear()}observe(t){let{managersByElement:n}=e,r=n.get(t);if(r!==this){if(r!=null&&r!==this)throw Error(`ResizeManager.observe: element is already owned by another ResizeManager`);n.set(t,this),e.getResizeObserver().observe(t)}}unobserve(t){let{managersByElement:n,resizeObserver:r}=e,i=n.get(t);if(i!=null){if(i!==this)throw Error(`ResizeManager.unobserve: element is owned by another ResizeManager`);n.delete(t),r?.unobserve(t),r!=null&&n.size===0&&(r.disconnect(),e.resizeObserver=void 0)}}handleResizeEntries(e){let t=new Map,n=new Set;for(let r of e){let{target:e,borderBoxSize:i,contentBoxSize:a}=r;if(!(e instanceof HTMLElement)){console.error(`ResizeManager.handleResizeEntries: Invalid element for ResizeObserver`,r);continue}let o=this.observedNodes.get(e);if(o==null){console.error(`ResizeManager.handleResizeEntries: Not a valid observed node`,r);continue}if(o.type===`annotations`){let t=(()=>{if(e===o.column1.child)return o.column1;if(e===o.column2.child)return o.column2})();if(t==null){console.error(`ResizeManager.handleResizeEntries: Couldn't find a column for`,{item:o,target:e});continue}t.childHeight=i[0].blockSize,n.add(o)}else if(o.type===`code`){let n=t.get(o)??{},r=a[0].inlineSize;e===o.codeElement?n.codeInlineSize=r:e===o.numberElement&&(n.numberInlineSize=r),t.set(o,n)}}this.applyAnnotationUpdates(n),n.clear(),this.applyColumnUpdates(t),t.clear()}applyAnnotationUpdates(e){for(let t of e)this.applyNewHeight(t,Math.max(t.column1.childHeight,t.column2.childHeight))}applyColumnUpdates=e=>{for(let[t,n]of e){let e=n.codeInlineSize==null?t.codeWidth:Oe(n.codeInlineSize),r=n.numberInlineSize==null?t.numberWidth:ke(n.numberInlineSize),i=e!==t.codeWidth,a=r!==t.numberWidth;!i&&!a||(t.codeWidth=e,t.numberWidth=r,t.applyColumnVariables&&G(t,{codeWidthChanged:i,numberWidthChanged:a}))}};applyNewHeight(e,t){t!==e.currentHeight&&(e.currentHeight=Math.max(t,0),e.column1.container.style.setProperty(`--diffs-annotation-min-height`,`${e.currentHeight}px`),e.column2.container.style.setProperty(`--diffs-annotation-min-height`,`${e.currentHeight}px`))}};function Oe(e){let t=Math.max(Math.floor(e),0);return t===0?`auto`:t}function ke(e){return Math.max(Math.ceil(e),0)}function Ae(e,t){e.applyColumnVariables!==t&&(e.applyColumnVariables=t,t?G(e,{codeWidthChanged:!0,numberWidthChanged:!0}):K(e))}function G(e,{codeWidthChanged:t,numberWidthChanged:n}){let{codeElement:r,codeWidth:i,numberWidth:a}=e;if(t&&r.style.setProperty(`--diffs-column-width`,`${typeof i==`number`?`${i}px`:`auto`}`),n&&r.style.setProperty(`--diffs-column-number-width`,`${a===0?`auto`:`${a}px`}`),t||n&&i!==`auto`){let e=typeof i==`number`?Math.max(i-a,0):0;r.style.setProperty(`--diffs-column-content-width`,`${e>0?`${e}px`:`auto`}`)}}function K(e){e.codeElement.style.removeProperty(`--diffs-column-content-width`),e.codeElement.style.removeProperty(`--diffs-column-number-width`),e.codeElement.style.removeProperty(`--diffs-column-width`)}function je(e){e.codeElement.isConnected&&K(e)}function Me(e){e.column1.container.isConnected&&e.column1.container.style.removeProperty(`--diffs-annotation-min-height`),e.column2.container.isConnected&&e.column2.container.style.removeProperty(`--diffs-annotation-min-height`)}function Ne(e,t){return e==null||t==null?e===t:e.startingLine===t.startingLine&&e.totalLines===t.totalLines&&e.bufferBefore===t.bufferBefore&&e.bufferAfter===t.bufferAfter}function Pe(e){for(let t of Array.isArray(e)?e:[e])if(t!==`text`&&t!==`ansi`&&!ee.has(t))return!1;return!0}function Fe(e){for(let t of h(e))if(!_.has(t))return!1;return!0}function Ie(e,t){return e.endsWith(`\r
`)?t+`\r
`:e.endsWith(`\r`)?t+`\r`:e.endsWith(`
`)?t+`
`:t}function Le(e){return x({tagName:`div`,children:[x({tagName:`div`,children:e.annotations?.map(e=>x({tagName:`slot`,properties:{name:e}})),properties:{"data-annotation-content":``}})],properties:{"data-line-annotation":`${e.hunkIndex},${e.lineIndex}`}})}function Re(e,t){return x({tagName:`div`,children:e,properties:{"data-content":``,style:`grid-row: span ${t}`}})}function q(e){switch(e){case`file`:return`diffs-icon-file-code`;case`change`:return`diffs-icon-symbol-modified`;case`new`:return`diffs-icon-symbol-added`;case`deleted`:return`diffs-icon-symbol-deleted`;case`rename-pure`:case`rename-changed`:return`diffs-icon-symbol-moved`}}function ze({fileOrDiff:e,mode:t,stickyHeader:n}){let r=`type`in e?e:void 0,i={"data-diffs-header":t,"data-change-type":r?.type,"data-sticky":n?``:void 0};return x({tagName:`div`,children:[t===`custom`?x({tagName:`slot`,properties:{name:d}}):Be({name:e.name,prevName:`prevName`in e?e.prevName:void 0,iconType:r?.type??`file`}),...t===`custom`?[]:[Ve(r)]],properties:i})}function Be({name:e,prevName:t,iconType:n}){let r=[x({tagName:`slot`,properties:{name:u}}),y({name:q(n),properties:{"data-change-icon":n}})];return t!=null&&(r.push(x({tagName:`div`,children:[x({tagName:`bdi`,children:[v(t)]})],properties:{"data-prev-name":``}})),r.push(y({name:`diffs-icon-arrow-right-short`,properties:{"data-rename-icon":``}}))),r.push(x({tagName:`div`,children:[x({tagName:`bdi`,children:[v(e)]})],properties:{"data-title":``}})),r.push(x({tagName:`slot`,properties:{name:a}})),x({tagName:`div`,children:r,properties:{"data-header-content":``}})}function Ve(e){let t=[];if(e!=null){let n=0,r=0;for(let t of e.hunks)n+=t.additionLines,r+=t.deletionLines;(r>0||n===0)&&t.push(x({tagName:`span`,children:[v(`-${r}`)],properties:{"data-deletions-count":``}})),(n>0||r===0)&&t.push(x({tagName:`span`,children:[v(`+${n}`)],properties:{"data-additions-count":``}}))}return t.push(x({tagName:`slot`,properties:{name:s}})),x({tagName:`div`,children:t,properties:{"data-metadata":``}})}function He(e){return x({tagName:`pre`,properties:Ue(e)})}function Ue({diffIndicators:e,disableBackground:t,disableLineNumbers:n,overflow:r,split:i,totalLines:a,type:o,customProperties:s}){return{...s,"data-diff":o===`diff`?``:void 0,"data-file":o===`file`?``:void 0,"data-diff-type":o===`diff`?i?`split`:`single`:void 0,"data-overflow":r,"data-disable-line-numbers":n?``:void 0,"data-background":t?void 0:``,"data-indicators":e===`bars`||e===`classic`?e:void 0,style:`--diffs-min-number-column-width-default:${`${a}`.length}ch;`}}function We(e,{theme:t,preferredHighlighter:n=`shiki-js`}){return{langs:[e??`text`],themes:h(t),preferredHighlighter:n}}var Ge=`<svg data-icon-sprite aria-hidden="true" width="0" height="0">
  <symbol id="diffs-icon-arrow-right-short" viewBox="0 0 16 16">
    <path d="M8.47 4.22a.75.75 0 0 0 0 1.06l1.97 1.97H3.75a.75.75 0 0 0 0 1.5h6.69l-1.97 1.97a.75.75 0 1 0 1.06 1.06l3.25-3.25a.75.75 0 0 0 0-1.06L9.53 4.22a.75.75 0 0 0-1.06 0"/>
  </symbol>
  <symbol id="diffs-icon-brand-github" viewBox="0 0 16 16">
    <path d="M8 0c4.42 0 8 3.58 8 8a8.01 8.01 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27s-1.36.09-2 .27c-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8"/>
  </symbol>
  <symbol id="diffs-icon-chevron" viewBox="0 0 16 16">
    <path d="M1.47 4.47a.75.75 0 0 1 1.06 0L8 9.94l5.47-5.47a.75.75 0 1 1 1.06 1.06l-6 6a.75.75 0 0 1-1.06 0l-6-6a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-chevrons-narrow" viewBox="0 0 10 16">
    <path d="M4.47 2.22a.75.75 0 0 1 1.06 0l3.25 3.25a.75.75 0 0 1-1.06 1.06L5 3.81 2.28 6.53a.75.75 0 0 1-1.06-1.06zM1.22 9.47a.75.75 0 0 1 1.06 0L5 12.19l2.72-2.72a.75.75 0 0 1 1.06 1.06l-3.25 3.25a.75.75 0 0 1-1.06 0l-3.25-3.25a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-diff-split" viewBox="0 0 16 16">
    <path d="M14 0H8.5v16H14a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2m-1.5 6.5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0"/><path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h5.5V0zm.5 7.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1 0-1" opacity=".3"/>
  </symbol>
  <symbol id="diffs-icon-diff-unified" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M16 14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V8.5h16zm-8-4a.5.5 0 0 0-.5.5v1h-1a.5.5 0 0 0 0 1h1v1a.5.5 0 0 0 1 0v-1h1a.5.5 0 0 0 0-1h-1v-1A.5.5 0 0 0 8 10" clip-rule="evenodd"/><path fill-rule="evenodd" d="M14 0a2 2 0 0 1 2 2v5.5H0V2a2 2 0 0 1 2-2zM6.5 3.5a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1z" clip-rule="evenodd" opacity=".4"/>
  </symbol>
  <symbol id="diffs-icon-expand" viewBox="0 0 16 16">
    <path d="M3.47 5.47a.75.75 0 0 1 1.06 0L8 8.94l3.47-3.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 0 1 0-1.06"/>
  </symbol>
  <symbol id="diffs-icon-expand-all" viewBox="0 0 16 16">
    <path d="M11.47 9.47a.75.75 0 1 1 1.06 1.06l-4 4a.75.75 0 0 1-1.06 0l-4-4a.75.75 0 1 1 1.06-1.06L8 12.94zM7.526 1.418a.75.75 0 0 1 1.004.052l4 4a.75.75 0 1 1-1.06 1.06L8 3.06 4.53 6.53a.75.75 0 1 1-1.06-1.06l4-4z"/>
  </symbol>
  <symbol id="diffs-icon-file-code" viewBox="0 0 16 16">
    <path d="M10.75 0c.199 0 .39.08.53.22l3.5 3.5c.14.14.22.331.22.53v9A2.75 2.75 0 0 1 12.25 16h-8.5A2.75 2.75 0 0 1 1 13.25V2.75A2.75 2.75 0 0 1 3.75 0zm-7 1.5c-.69 0-1.25.56-1.25 1.25v10.5c0 .69.56 1.25 1.25 1.25h8.5c.69 0 1.25-.56 1.25-1.25V5h-1.25A2.25 2.25 0 0 1 10 2.75V1.5z"/><path d="M7.248 6.19a.75.75 0 0 1 .063 1.058L5.753 9l1.558 1.752a.75.75 0 0 1-1.122.996l-2-2.25a.75.75 0 0 1 0-.996l2-2.25a.75.75 0 0 1 1.06-.063M8.69 7.248a.75.75 0 1 1 1.12-.996l2 2.25a.75.75 0 0 1 0 .996l-2 2.25a.75.75 0 1 1-1.12-.996L10.245 9z"/>
  </symbol>
  <symbol id="diffs-icon-plus" viewBox="0 0 16 16">
    <path d="M8 3a.75.75 0 0 1 .75.75v3.5h3.5a.75.75 0 0 1 0 1.5h-3.5v3.5a.75.75 0 0 1-1.5 0v-3.5h-3.5a.75.75 0 0 1 0-1.5h3.5v-3.5A.75.75 0 0 1 8 3"/>
  </symbol>
  <symbol id="diffs-icon-symbol-added" viewBox="0 0 16 16">
    <path d="M8 4a.75.75 0 0 1 .75.75v2.5h2.5a.75.75 0 0 1 0 1.5h-2.5v2.5a.75.75 0 0 1-1.5 0v-2.5h-2.5a.75.75 0 0 1 0-1.5h2.5v-2.5A.75.75 0 0 1 8 4"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-deleted" viewBox="0 0 16 16">
    <path d="M4 8a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 0 1.5h-6.5A.75.75 0 0 1 4 8"/><path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/>
  </symbol>
  <symbol id="diffs-icon-symbol-diffstat" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.75 4.296a.75.75 0 0 0-1.5 0V6.25h-2a.75.75 0 0 0 0 1.5h2v1.5h1.5v-1.5h2a.75.75 0 0 0 0-1.5h-2zM5.25 10a.75.75 0 0 0 0 1.5h5.5a.75.75 0 0 0 0-1.5z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ignored" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m11.53-2.47a.75.75 0 0 0-1.06-1.06l-6 6a.75.75 0 1 0 1.06 1.06z"/>
  </symbol>
  <symbol id="diffs-icon-symbol-modified" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706s.826.607 1.706.802c.898.2 2.091.288 3.704.288s2.806-.088 3.704-.288c.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5s-2.806.088-3.704.288c-.88.196-1.381.478-1.706.802s-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8M0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m8 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
  </symbol>
  <symbol id="diffs-icon-symbol-moved" viewBox="0 0 16 16">
    <path d="M1.788 4.296c.196-.88.478-1.381.802-1.706s.826-.606 1.706-.802C5.194 1.588 6.387 1.5 8 1.5s2.806.088 3.704.288c.88.196 1.381.478 1.706.802s.607.826.802 1.706c.2.898.288 2.091.288 3.704s-.088 2.806-.288 3.704c-.195.88-.478 1.381-.802 1.706s-.826.607-1.706.802c-.898.2-2.091.288-3.704.288s-2.806-.088-3.704-.288c-.88-.195-1.381-.478-1.706-.802s-.606-.826-.802-1.706C1.588 10.806 1.5 9.613 1.5 8s.088-2.806.288-3.704M8 0C1.412 0 0 1.412 0 8s1.412 8 8 8 8-1.412 8-8-1.412-8-8-8"/><path d="M8.495 4.695a.75.75 0 0 0-.05 1.06L10.486 8l-2.041 2.246a.75.75 0 0 0 1.11 1.008l2.5-2.75a.75.75 0 0 0 0-1.008l-2.5-2.75a.75.75 0 0 0-1.06-.051m-4 0a.75.75 0 0 0-.05 1.06l2.044 2.248-1.796 1.995a.75.75 0 0 0 1.114 1.004l2.25-2.5a.75.75 0 0 0-.002-1.007l-2.5-2.75a.75.75 0 0 0-1.06-.05"/>
  </symbol>
  <symbol id="diffs-icon-symbol-ref" viewBox="0 0 16 16">
    <path d="M1.5 8c0 1.613.088 2.806.288 3.704.196.88.478 1.381.802 1.706.286.286.71.54 1.41.73V1.86c-.7.19-1.124.444-1.41.73-.324.325-.606.826-.802 1.706C1.588 5.194 1.5 6.387 1.5 8m4 6.397c.697.07 1.522.103 2.5.103 1.613 0 2.806-.088 3.704-.288.88-.195 1.381-.478 1.706-.802s.607-.826.802-1.706c.2-.898.288-2.091.288-3.704s-.088-2.806-.288-3.704c-.195-.88-.478-1.381-.802-1.706s-.826-.606-1.706-.802C10.806 1.588 9.613 1.5 8 1.5c-.978 0-1.803.033-2.5.103zM0 8c0-6.588 1.412-8 8-8s8 1.412 8 8-1.412 8-8 8-8-1.412-8-8m7-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1z"/>
  </symbol>
</svg>`;function Ke(e,t){return e==null||t==null?e===t:Je(e.customProperties,t.customProperties)&&e.type===t.type&&e.diffIndicators===t.diffIndicators&&e.disableBackground===t.disableBackground&&e.disableLineNumbers===t.disableLineNumbers&&e.overflow===t.overflow&&e.split===t.split&&e.totalLines===t.totalLines}var qe={};function Je(e=qe,t=qe){if(e===t)return!0;let n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(let r of n)if(e[r]!==t[r])return!1;return!0}function Ye(e){let t=document.createElement(`div`);return t.dataset.annotationSlot=``,t.slot=e,t.style.whiteSpace=`normal`,t}function Xe(){let e=document.createElement(`div`);return e.slot=`gutter-utility-slot`,e.style.position=`absolute`,e.style.top=`0`,e.style.bottom=`0`,e.style.textAlign=`center`,e.style.whiteSpace=`normal`,e.style.touchAction=`none`,e}function Ze(){let e=document.createElement(`style`);return e.setAttribute(m,``),e}var J;function Qe(e){if(J!=null)return J;let t=e.host;if(typeof HTMLElement<`u`&&t instanceof HTMLElement&&!t.isConnected)return;let n=document.createElement(`div`);n.setAttribute(`data-code`,``),n.setAttribute(c,`true`);let r=document.createElement(`div`);return r.style.position=`relative`,r.style.width=`200%`,r.style.height=`200%`,n.appendChild(r),e.appendChild(n),J=Math.max(n.offsetHeight-n.clientHeight,0),n.remove(),J}function $e(e){return`${p}: ${e==null?`var(--diffs-scrollbar-gutter-fallback)`:`${e}px`};`}var et=`@layer base {
  :host {
    --diffs-font-fallback: "SF Mono", Monaco, Consolas, "Ubuntu Mono", "Liberation Mono",
      "Courier New", monospace;
    --diffs-header-font-fallback: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue",
      "Noto Sans", "Liberation Sans", Arial, sans-serif;
    --diffs-mixer: light-dark(#000, #fff);
    --diffs-gap-fallback: 8px;
    --diffs-scrollbar-gutter-fallback: 6px;
    --diffs-scrollbar-gutter: var(--diffs-scrollbar-gutter-override, var(--diffs-scrollbar-gutter-measured, var(--diffs-scrollbar-gutter-fallback)));
    --diffs-added-light: #0dbe4e;
    --diffs-added-dark: #5ecc71;
    --diffs-modified-light: #009fff;
    --diffs-modified-dark: #69b1ff;
    --diffs-deleted-light: #ff2e3f;
    --diffs-deleted-dark: #ff6762;
    --diffs-warning-light: #d5a910;
    --diffs-warning-dark: #ffd452;
    color-scheme: light dark;
    font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));
    font-size: var(--diffs-font-size, 13px);
    line-height: var(--diffs-line-height, 20px);
    font-feature-settings: var(--diffs-font-features);
    --diffs-bg: light-dark(var(--diffs-light-bg, #fff), var(--diffs-dark-bg, #000));
    --diffs-bg-buffer: var(--diffs-bg-buffer-override, light-dark(color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-bg) 92%, var(--diffs-mixer))));
    --diffs-bg-context: var(--diffs-bg-context-override, light-dark(color-mix(in lab, var(--diffs-bg) 98.5%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-bg) 92.5%, var(--diffs-mixer))));
    --diffs-bg-context-gutter: var(--diffs-bg-context-gutter-override, light-dark(color-mix(in lab, var(--diffs-bg-context) 90%, var(--diffs-bg)), color-mix(in lab, var(--diffs-bg-context) 45%, var(--diffs-bg))));
    --diffs-bg-separator: var(--diffs-bg-separator-override, light-dark(color-mix(in lab, var(--diffs-bg) 96%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-bg) 85%, var(--diffs-mixer))));
    --diffs-fg: light-dark(var(--diffs-light, #000), var(--diffs-dark, #fff));
    --diffs-fg-number: var(--diffs-fg-number-override, light-dark(color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg)), color-mix(in lab, var(--diffs-fg) 65%, var(--diffs-bg))));
    --diffs-fg-conflict-marker: var(--diffs-fg-conflict-marker-override, var(--diffs-fg-number));
    --diffs-deletion-base: var(--diffs-deletion-color-override, light-dark(var(--diffs-light-deletion-color, var(--diffs-deletion-color, var(--diffs-deleted-light))), var(--diffs-dark-deletion-color, var(--diffs-deletion-color, var(--diffs-deleted-dark)))));
    --diffs-addition-base: var(--diffs-addition-color-override, light-dark(var(--diffs-light-addition-color, var(--diffs-addition-color, var(--diffs-added-light))), var(--diffs-dark-addition-color, var(--diffs-addition-color, var(--diffs-added-dark)))));
    --diffs-modified-base: var(--diffs-modified-color-override, light-dark(var(--diffs-light-modified-color, var(--diffs-modified-color, var(--diffs-modified-light))), var(--diffs-dark-modified-color, var(--diffs-modified-color, var(--diffs-modified-dark)))));
    --diffs-bg-deletion: var(--diffs-bg-deletion-override, light-dark(color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-deletion-base)), color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-deletion-base))));
    --diffs-bg-deletion-emphasis: var(--diffs-bg-deletion-emphasis-override, light-dark(rgb(from var(--diffs-deletion-base) r g b / .15), rgb(from var(--diffs-deletion-base) r g b / .2)));
    --diffs-bg-addition: var(--diffs-bg-addition-override, light-dark(color-mix(in lab, var(--diffs-bg) 88%, var(--diffs-addition-base)), color-mix(in lab, var(--diffs-bg) 80%, var(--diffs-addition-base))));
    --diffs-bg-addition-emphasis: var(--diffs-bg-addition-emphasis-override, light-dark(rgb(from var(--diffs-addition-base) r g b / .15), rgb(from var(--diffs-addition-base) r g b / .2)));
    --diffs-selection-base: var(--diffs-modified-base);
    --diffs-selection-number-fg: light-dark(color-mix(in lab, var(--diffs-selection-base) 65%, var(--diffs-mixer)), color-mix(in lab, var(--diffs-selection-base) 75%, var(--diffs-mixer)));
    background-color: var(--diffs-bg);
    color: var(--diffs-fg);
    display: block;
  }

  pre, code, [data-error-wrapper] {
    isolation: isolate;
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
    outline: none;
    margin: 0;
    padding: 0;
    display: block;
  }

  pre, code {
    background-color: var(--diffs-bg);
  }

  code {
    contain: content;
  }

  input, button {
    font-family: inherit;
    font-size: inherit;
    line-height: inherit;
  }

  *, :before, :after {
    box-sizing: border-box;
  }

  [data-icon-sprite] {
    display: none;
  }

  [data-diffs-header], [data-separator] {
    font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));
  }

  [data-diffs-header][data-sticky] {
    z-index: 1;
    background-color: var(--diffs-bg);
    position: sticky;
    top: 0;
  }

  [data-file-info] {
    color: var(--fg);
    background-color: color-mix(in lab, var(--bg) 98%, var(--fg));
    border-block: 1px solid color-mix(in lab, var(--bg) 95%, var(--fg));
    padding: 10px;
    font-weight: 700;
  }

  [data-diff], [data-file] {
    --diffs-grid-number-column-width: minmax(min-content, max-content);
    --diffs-code-grid: var(--diffs-grid-number-column-width) 1fr;

    &[data-dehydrated] {
      --diffs-code-grid: var(--diffs-grid-number-column-width) minmax(0, 1fr);
    }

    &:hover [data-code]::-webkit-scrollbar-thumb {
      background-color: var(--diffs-bg-context);
    }
  }

  @supports (-webkit-touch-callout: none) {
    :host {
      --diffs-scrollbar-gutter-fallback: 0px;
    }
  }

  [data-line] span {
    color: light-dark(var(--diffs-token-light, var(--diffs-light)), var(--diffs-token-dark, var(--diffs-dark)));
    background-color: light-dark(var(--diffs-token-light-bg, inherit), var(--diffs-token-dark-bg, inherit));
    font-weight: light-dark(var(--diffs-token-light-font-weight, inherit), var(--diffs-token-dark-font-weight, inherit));
    font-style: light-dark(var(--diffs-token-light-font-style, inherit), var(--diffs-token-dark-font-style, inherit));
    text-decoration: light-dark(var(--diffs-token-light-text-decoration, inherit), var(--diffs-token-dark-text-decoration, inherit));
  }

  [data-line], [data-gutter-buffer], [data-column-number], [data-line-annotation], [data-no-newline], [data-merge-conflict], [data-merge-conflict-actions], [data-editor-overlay] {
    --diffs-computed-decoration-bg: var(--diffs-bg);
    --diffs-computed-diff-line-bg: var(--diffs-computed-decoration-bg);
    --diffs-computed-selected-line-bg: var(--diffs-computed-diff-line-bg);
    --diffs-computed-editor-active-line-bg: var(--diffs-computed-selected-line-bg);
    --diffs-computed-hovered-line-bg: var(--diffs-computed-editor-active-line-bg);
    --diffs-hover-mix-target: var(--diffs-bg-hover-override, var(--diffs-mixer));
    --diffs-line-bg: var(--diffs-computed-hovered-line-bg);
    color: var(--diffs-fg);
    background-color: var(--diffs-line-bg, var(--diffs-bg));
  }

  [data-line], [data-no-newline] {
    &[data-decoration-bg] {
      --mix-deco-light: 92%;
      --mix-deco-dark: 85%;

      &[data-decoration-bg-depth="2"] {
        --mix-deco-light: 88%;
        --mix-deco-dark: 80%;
      }

      &[data-decoration-bg-depth="3"] {
        --mix-deco-light: 85%;
        --mix-deco-dark: 78%;
      }

      --diffs-hover-mix-target: var(--diffs-decoration-bg);
      --diffs-computed-decoration-bg: light-dark(color-mix(in lab,
          var(--diffs-bg) var(--mix-deco-light),
          var(--diffs-decoration-bg)), color-mix(in lab,
          var(--diffs-bg) var(--mix-deco-dark),
          var(--diffs-decoration-bg)));
    }
  }

  [data-line-annotation], [data-gutter-buffer="annotation"] {
    --diffs-annotation-bg: var(--diffs-bg-context);
    --diffs-computed-decoration-bg: var(--diffs-annotation-bg);
    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);
  }

  [data-merge-conflict-actions], [data-gutter-buffer="merge-conflict-action"], [data-gutter-buffer="merge-conflict-marker-base"], [data-gutter-buffer="merge-conflict-marker-separator"], [data-merge-conflict="marker-base"], [data-merge-conflict="marker-separator"] {
    --diffs-computed-decoration-bg: var(--diffs-bg-context);
    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);
  }

  [data-gutter-buffer="merge-conflict-marker-start"], [data-merge-conflict="marker-start"] {
    --diffs-computed-decoration-bg: light-dark(color-mix(in lab,
        var(--diffs-bg) 78%,
        var(--conflict-bg-current-header-override, var(--diffs-addition-base))), color-mix(in lab,
        var(--diffs-bg) 68%,
        var(--conflict-bg-current-header-override, var(--diffs-addition-base))));
    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);
  }

  [data-gutter-buffer="merge-conflict-marker-end"], [data-merge-conflict="marker-end"] {
    --diffs-computed-decoration-bg: light-dark(color-mix(in lab,
        var(--diffs-bg) 78%,
        var(--conflict-bg-incoming-header-override, var(--diffs-modified-base))), color-mix(in lab,
        var(--diffs-bg) 68%,
        var(--conflict-bg-incoming-header-override, var(--diffs-modified-base))));
    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);
  }

  [data-has-merge-conflict] [data-line-annotation], [data-has-merge-conflict] [data-gutter-buffer="annotation"] {
    --diffs-computed-decoration-bg: var(--diffs-bg);
    --diffs-hover-mix-target: var(--diffs-computed-editor-active-line-bg);
  }

  :where([data-background]) {
    & [data-gutter-buffer], & [data-column-number] {
      --mix-light: 91%;
      --mix-dark: 85%;
    }

    & [data-line], & [data-no-newline] {
      --mix-light: 88%;
      --mix-dark: 80%;
    }

    & [data-gutter-buffer], & [data-column-number], & [data-line], & [data-no-newline] {
      --diffs-diff-line-mix-target: var(--diffs-bg);

      &[data-line-type="change-deletion"] {
        --diffs-diff-line-mix-target: var(--diffs-bg-deletion-override, var(--diffs-deletion-base));
        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);

        &:where([data-gutter-buffer], [data-column-number]) {
          color: var(--diffs-fg-number-deletion-override, var(--diffs-deletion-base));
          --diffs-diff-line-mix-target: var(--diffs-bg-deletion-number-override, var(--diffs-deletion-base));
        }

        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-light),
            var(--diffs-diff-line-mix-target)), color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-dark),
            var(--diffs-diff-line-mix-target)));
      }

      &[data-line-type="change-addition"] {
        --diffs-diff-line-mix-target: var(--diffs-bg-addition-override, var(--diffs-addition-base));
        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);

        &:where([data-gutter-buffer], [data-column-number]) {
          color: var(--diffs-fg-number-addition-override, var(--diffs-addition-base));
          --diffs-diff-line-mix-target: var(--diffs-bg-addition-number-override, var(--diffs-addition-base));
        }

        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-light),
            var(--diffs-diff-line-mix-target)), color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-dark),
            var(--diffs-diff-line-mix-target)));
      }

      &[data-merge-conflict="current"] {
        --diffs-diff-line-mix-target: var(--conflict-bg-current-override, var(--diffs-addition-base));
        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);

        &:where([data-gutter-buffer], [data-column-number]) {
          color: var(--diffs-fg-number-addition-override, var(--diffs-addition-base));
          --diffs-diff-line-mix-target: var(--conflict-bg-current-number-override, var(--diffs-addition-base));
        }

        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-light),
            var(--diffs-diff-line-mix-target)), color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-dark),
            var(--diffs-diff-line-mix-target)));
      }

      &[data-merge-conflict="incoming"] {
        --diffs-diff-line-mix-target: var(--conflict-bg-incoming-override, var(--diffs-modified-base));
        --diffs-hover-mix-target: var(--diffs-diff-line-mix-target);

        &:where([data-gutter-buffer], [data-column-number]) {
          color: var(--diffs-modified-base);
          --diffs-diff-line-mix-target: var(--conflict-bg-incoming-number-override, var(--diffs-modified-base));
        }

        --diffs-computed-diff-line-bg: light-dark(color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-light),
            var(--diffs-diff-line-mix-target)), color-mix(in lab,
            var(--diffs-computed-decoration-bg) var(--mix-dark),
            var(--diffs-diff-line-mix-target)));
      }
    }
  }

  [data-gutter-buffer], [data-column-number], [data-line], [data-line-annotation], [data-merge-conflict], [data-merge-conflict-actions], [data-no-newline], [data-editor-overlay] {
    --diffs-selection-mix-target: var(--diffs-bg-selection-override, var(--diffs-selection-base));
    --diffs-selection-emphasis-mix-target: var(--diffs-selection-mix-target);

    &:where([data-editor-overlay]), &:where([data-line], [data-line-annotation], [data-merge-conflict], [data-merge-conflict-actions], [data-no-newline])[data-selected-line] {
      --mix-selection-light: 82%;
      --mix-selection-dark: 75%;
      --diffs-hover-mix-target: var(--diffs-selection-mix-target);
    }

    &:where([data-gutter-buffer][data-selected-line], [data-column-number]:is([data-selected-line], [data-editor-active-line])) {
      --mix-selection-light: 75%;
      --mix-selection-dark: 60%;
      --diffs-selection-mix-target: var(--diffs-bg-selection-number-override, var(--diffs-selection-base));
      --diffs-hover-mix-target: var(--diffs-selection-mix-target);
    }

    &:where([data-line][data-selected-line]):is([data-line-type="change-addition"], [data-line-type="change-deletion"]) {
      --diffs-selection-emphasis-mix-target: light-dark(color-mix(in lab,
          var(--diffs-diff-line-mix-target, var(--diffs-selection-mix-target))
            var(--mix-selection-light),
          var(--diffs-selection-mix-target)), var(--diffs-selection-mix-target));
    }

    &:where([data-editor-overlay]), &[data-selected-line] {
      --diffs-computed-selected-line-bg: light-dark(color-mix(in lab,
          var(--diffs-computed-diff-line-bg) var(--mix-selection-light),
          var(--diffs-selection-mix-target)), color-mix(in lab,
          var(--diffs-computed-diff-line-bg) var(--mix-selection-dark),
          var(--diffs-selection-mix-target)));
    }
  }

  [data-line][data-editor-active-line], [data-column-number][data-editor-active-line] {
    --diffs-computed-editor-active-line-bg: color-mix(in lab,
      var(--diffs-computed-selected-line-bg)
        var(--diffs-editor-active-line-source-mix, 100%),
      var(--diffs-selection-emphasis-mix-target));
  }

  @media (pointer: fine) {
    [data-line][data-hovered], [data-gutter-buffer][data-hovered], [data-column-number][data-hovered], [data-line-annotation][data-hovered], [data-no-newline][data-hovered], [data-merge-conflict][data-hovered], [data-merge-conflict-actions][data-hovered], [data-editor-overlay][data-hovered] {
      --diffs-computed-hovered-line-bg: light-dark(color-mix(in lab,
          var(--diffs-computed-editor-active-line-bg) 97%,
          var(--diffs-hover-mix-target)), color-mix(in lab,
          var(--diffs-computed-editor-active-line-bg) 91%,
          var(--diffs-hover-mix-target)));
    }
  }

  [data-gutter-buffer][data-selected-line], [data-column-number]:is([data-selected-line], [data-editor-active-line]) {
    color: var(--diffs-selection-number-fg);
  }

  [data-no-newline] {
    user-select: none;

    & span {
      opacity: .6;
    }
  }

  [data-diff-type="split"][data-overflow="scroll"] {
    grid-template-columns: 1fr 1fr;
    display: grid;

    & [data-additions] {
      border-left: 1px solid var(--diffs-bg);
    }

    & [data-deletions] {
      border-right: 1px solid var(--diffs-bg);
    }
  }

  [data-code] {
    grid-auto-flow: dense;
    grid-template-columns: var(--diffs-code-grid);
    overflow: var(--diffs-overflow-override, scroll) clip;
    overscroll-behavior-x: none;
    tab-size: var(--diffs-tab-size, 2);
    padding-top: var(--diffs-gap-block, var(--diffs-gap-fallback));
    padding-bottom: max(0px,
      calc(var(--diffs-gap-block, var(--diffs-gap-fallback)) -
          var(--diffs-scrollbar-gutter)));
    scrollbar-gutter: stable;
    align-self: flex-start;
    display: grid;
  }

  [data-diffs-scrollbar-measure] {
    opacity: 0;
    pointer-events: none;
    scrollbar-gutter: auto;
    grid-template-columns: none;
    width: 100px;
    height: 100px;
    padding: 0;
    position: absolute;
    top: -200px;
    left: -200px;
  }

  [data-container-size] {
    container-type: inline-size;
  }

  [data-code]::-webkit-scrollbar {
    width: 0;
    height: var(--diffs-scrollbar-gutter);
  }

  [data-code]::-webkit-scrollbar-track {
    background: none;
  }

  [data-code]::-webkit-scrollbar-thumb {
    background-color: #0000;
    background-clip: content-box;
    border: 1px solid #0000;
    border-radius: 3px;
  }

  [data-code]::-webkit-scrollbar-corner {
    background-color: #0000;
  }

  @supports ((-moz-appearance: none)) {
    [data-code] {
      scrollbar-width: thin;
      scrollbar-color: var(--diffs-bg-context) transparent;
      padding-bottom: var(--diffs-gap-block, var(--diffs-gap-fallback));
    }
  }

  [data-diffs-header] ~ [data-diff], [data-diffs-header] ~ [data-file] {
    & [data-code], &[data-overflow="wrap"], &[data-dehydrated][data-diff-type="split"][data-overflow="scroll"] {
      padding-top: 0;
    }
  }

  [data-gutter] {
    grid-template-rows: subgrid;
    grid-template-columns: subgrid;
    z-index: 3;
    background-color: var(--diffs-bg);
    grid-column: 1;
    display: grid;
    position: relative;

    & [data-gutter-buffer], & [data-column-number] {
      border-right: var(--diffs-gap-style, 2px solid var(--diffs-bg));
    }
  }

  [data-content] {
    grid-template-rows: subgrid;
    grid-template-columns: subgrid;
    background-color: var(--diffs-bg);
    grid-column: 2;
    min-width: 0;
    display: grid;
  }

  [data-diff-type="split"][data-overflow="wrap"], [data-dehydrated][data-diff-type="split"][data-overflow="scroll"] {
    grid-auto-flow: dense;
    grid-template-columns: repeat(2, var(--diffs-code-grid));
    padding-block: var(--diffs-gap-block, var(--diffs-gap-fallback));
    display: grid;

    & [data-code] {
      display: contents;
    }

    & [data-deletions] {
      & [data-gutter] {
        grid-column: 1;
      }

      & [data-content] {
        border-right: 1px solid var(--diffs-bg);
        grid-column: 2;
      }
    }

    & [data-additions] {
      & [data-gutter] {
        border-left: 1px solid var(--diffs-bg);
        grid-column: 3;
      }

      & [data-content] {
        grid-column: 4;
      }
    }
  }

  [data-dehydrated][data-diff-type="split"][data-overflow="scroll"] [data-content] {
    overflow: clip;
  }

  [data-overflow="scroll"] [data-gutter] {
    position: sticky;
    left: 0;
  }

  [data-interactive-lines] [data-line] {
    cursor: pointer;
  }

  [data-interactive-line-numbers] [data-column-number] {
    cursor: pointer;
    touch-action: none;
  }

  [data-content-buffer], [data-gutter-buffer] {
    user-select: none;
    min-height: 1lh;
    position: relative;
  }

  [data-gutter-buffer] {
    padding-left: 2ch;
    padding-right: 1ch;

    &:before {
      content: "";
      min-width: var(--diffs-min-number-column-width, var(--diffs-min-number-column-width-default, 3ch));
      display: block;
    }
  }

  [data-gutter-buffer="annotation"] {
    --diffs-annotation-bg: var(--diffs-bg-context-gutter);
    min-height: 0;
  }

  [data-gutter-buffer="buffer"] {
    --diffs-line-bg: var(--diffs-bg-context-gutter);
  }

  [data-content-buffer] {
    background-position: 5px 0;
    background-size: 8px 8px;
    background-origin: border-box;
    background-image: repeating-linear-gradient(-45deg,
      transparent,
      transparent calc(3px * 1.414),
      var(--diffs-bg-buffer) calc(3px * 1.414),
      var(--diffs-bg-buffer) calc(4px * 1.414));
    grid-column: 1;
  }

  [data-separator] {
    box-sizing: content-box;
    background-color: var(--diffs-bg);
  }

  [data-separator="simple"] {
    min-height: 4px;
  }

  [data-separator="line-info"], [data-separator="line-info-basic"], [data-separator="metadata"], [data-separator="simple"] {
    background-color: var(--diffs-bg-separator);
  }

  [data-separator="line-info"], [data-separator="line-info-basic"], [data-separator="metadata"] {
    height: 32px;
    position: relative;
  }

  [data-separator-wrapper] {
    user-select: none;
    fill: currentColor;
    background-color: var(--diffs-bg);
    align-items: center;
    height: 100%;
    display: flex;
    position: absolute;
    inset-inline: 0;
  }

  [data-content] [data-separator-wrapper] {
    display: none;
  }

  [data-separator="metadata"] [data-separator-wrapper] {
    background-color: var(--diffs-bg-separator);
    height: 100%;
    color: var(--diffs-fg-number);
    white-space: nowrap;
    text-overflow: ellipsis;
    min-width: min-content;
    padding-inline: 1ch;
    inset-inline: 100% auto;
    overflow: hidden;
  }

  [data-separator="line-info"] {
    margin-block: var(--diffs-gap-block, var(--diffs-gap-fallback));

    & [data-separator-wrapper] {
      min-width: 16px;
    }
  }

  [data-separator="line-info-basic"], [data-separator="metadata"] {
    margin-block: 0;
  }

  [data-separator="line-info"][data-separator-first] {
    margin-top: 0;
  }

  [data-separator="line-info"][data-separator-last] {
    margin-bottom: 0;
  }

  [data-expand-index] [data-separator-wrapper] {
    grid-template-columns: 32px auto;
    display: grid;
  }

  [data-expand-index] [data-separator-wrapper][data-separator-multi-button] {
    grid-template-columns: 32px 32px auto;
  }

  [data-expand-button], [data-separator-content] {
    background-color: var(--diffs-bg-separator);
    flex: none;
    align-items: center;
    display: flex;
  }

  [data-expand-index] [data-separator-content]:hover {
    cursor: pointer;
    text-decoration: underline;
  }

  [data-expand-button] {
    cursor: pointer;
    min-width: 32px;
    color: var(--diffs-fg-number);
    border-right: 2px solid var(--diffs-bg);
    flex-shrink: 0;
    justify-content: center;
    align-self: stretch;

    &:hover {
      color: var(--diffs-fg);
    }

    &[data-expand-all-button] {
      display: none;
    }
  }

  [data-expand-down] [data-icon] {
    transform: scaleY(-1);
  }

  [data-separator-content] {
    height: 100%;
    color: var(--diffs-fg-number);
    flex: auto;
    justify-content: flex-start;
    padding: 0 1ch;
    overflow: hidden;
  }

  [data-separator="line-info"], [data-separator="line-info-basic"] {
    & [data-separator-content] {
      user-select: none;
      height: 100%;
      overflow: clip;
    }
  }

  [data-unmodified-lines] {
    text-overflow: ellipsis;
    white-space: nowrap;
    flex: 0 auto;
    min-width: 0;
    display: block;
    overflow: hidden;
  }

  @supports (width: 1cqi) {
    [data-unified] {
      & [data-separator="line-info"] [data-separator-wrapper] {
        padding-inline: var(--diffs-gap-inline, var(--diffs-gap-fallback));
        width: 100cqi;

        & [data-separator-content] {
          border-radius: 6px;
        }
      }

      & [data-separator="line-info"][data-expand-index] [data-separator-wrapper] [data-separator-content] {
        border-top-left-radius: unset;
        border-bottom-left-radius: unset;
      }
    }

    [data-gutter] {
      & [data-separator="line-info"] [data-separator-wrapper] {
        padding-left: var(--diffs-gap-inline, var(--diffs-gap-fallback));
      }

      & [data-separator="line-info"] [data-separator-content] {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px;
      }

      & [data-separator="line-info"][data-expand-index] [data-separator-content] {
        border-top-left-radius: unset;
        border-bottom-left-radius: unset;
      }
    }

    [data-additions] {
      & [data-content] [data-separator="line-info"] {
        background-color: var(--diffs-bg);

        & [data-separator-wrapper] {
          display: none;
        }
      }

      & [data-gutter] [data-separator="line-info"] [data-separator-wrapper] {
        background-color: var(--diffs-bg-separator);
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px;
        height: 100%;
        display: block;

        & [data-separator-content], & [data-expand-button] {
          display: none;
        }
      }
    }

    [data-overflow="scroll"] [data-additions] [data-gutter] [data-separator="line-info"] [data-separator-wrapper] {
      width: calc(100cqi - var(--diffs-gap-inline, var(--diffs-gap-fallback)));
    }

    [data-overflow="wrap"] [data-additions] [data-content] [data-separator="line-info"] [data-separator-wrapper] {
      background-color: var(--diffs-bg-separator);
      height: 100%;
      margin-right: var(--diffs-gap-inline, var(--diffs-gap-fallback));
      border-top-right-radius: 6px;
      border-bottom-right-radius: 6px;
      display: block;

      & [data-separator-content], & [data-expand-button] {
        display: none;
      }
    }

    [data-separator="line-info"] [data-separator-wrapper] {
      & [data-expand-both], & [data-expand-down], & [data-expand-up] {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px;
      }
    }

    @media (pointer: fine) {
      [data-separator="line-info"] [data-separator-wrapper] {
        &[data-separator-multi-button] {
          & [data-expand-up] {
            border-top-left-radius: 6px;
            border-bottom-left-radius: unset;
          }

          & [data-expand-down] {
            border-bottom-left-radius: 6px;
            border-top-left-radius: unset;
          }
        }
      }
    }
  }

  @media (pointer: coarse) {
    [data-separator="line-info-basic"] [data-separator-wrapper][data-separator-multi-button] {
      grid-template-columns: 34px 34px auto;

      & [data-separator-content] {
        grid-column: unset;
        grid-row: unset;
      }
    }

    @supports (width: 1cqi) {
      [data-separator="line-info"] [data-separator-wrapper] {
        & [data-expand-both], & [data-expand-down], & [data-expand-up] {
          border-top-left-radius: 6px;
          border-bottom-left-radius: 6px;
        }

        &[data-separator-multi-button] {
          & [data-expand-up] {
            border-top-left-radius: 6px;
            border-bottom-left-radius: 6px;
          }

          & [data-expand-down] {
            border-bottom-left-radius: unset;
            border-top-left-radius: unset;
          }
        }
      }
    }
  }

  @media (pointer: fine) {
    [data-separator-wrapper][data-separator-multi-button] {
      grid-template-rows: 50% 50%;
      display: grid;

      & [data-separator-content] {
        grid-area: 1 / 2 / -1;
        min-width: min-content;
      }

      & [data-expand-button] {
        grid-column: 1;
      }
    }

    [data-separator="line-info"] [data-separator-wrapper], [data-separator="line-info"] [data-separator-wrapper][data-separator-multi-button] {
      grid-template-columns: 34px auto;
    }

    [data-separator="line-info-basic"][data-expand-index] [data-separator-wrapper] {
      grid-template-columns: 100% auto;
    }

    [data-separator="line-info"], [data-separator="line-info-basic"] {
      & [data-separator-multi-button] {
        & [data-expand-up] {
          border-bottom: 1px solid var(--diffs-bg);
          border-right: 2px solid var(--diffs-bg);
        }

        & [data-expand-down] {
          border-top: 1px solid var(--diffs-bg);
          border-right: 2px solid var(--diffs-bg);
        }
      }
    }
  }

  [data-additions] [data-gutter] [data-separator-wrapper], [data-additions] [data-separator="line-info-basic"] [data-separator-wrapper], [data-content] [data-separator-wrapper] {
    display: none;
  }

  [data-line-annotation] {
    min-height: var(--diffs-annotation-min-height, 0);
    z-index: 2;
  }

  [data-merge-conflict-actions] {
    z-index: 2;
  }

  [data-separator="custom"] {
    grid-template-columns: subgrid;
    display: grid;
  }

  [data-line], [data-column-number], [data-no-newline] {
    padding-inline: 1ch;
    position: relative;
  }

  [data-indicators="classic"] [data-line] {
    padding-inline-start: 2ch;
  }

  [data-indicators="classic"] {
    & [data-line-type="change-addition"], & [data-line-type="change-deletion"] {
      &[data-no-newline], &[data-line] {
        &:before {
          user-select: none;
          width: 1ch;
          height: 1lh;
          display: inline-block;
          position: absolute;
          top: 0;
          left: 0;
        }
      }
    }

    & [data-line-type="change-addition"] {
      &[data-line], &[data-no-newline] {
        &:before {
          content: "+";
          color: var(--diffs-addition-base);
        }
      }
    }

    & [data-line-type="change-deletion"] {
      &[data-line], &[data-no-newline] {
        &:before {
          content: "-";
          color: var(--diffs-deletion-base);
        }
      }
    }
  }

  [data-indicators="bars"] {
    & [data-line-type="change-deletion"], & [data-line-type="change-addition"] {
      &[data-column-number] {
        &:before {
          content: "";
          user-select: none;
          contain: strict;
          width: 4px;
          height: 100%;
          display: block;
          position: absolute;
          top: 0;
          left: 0;
        }
      }
    }

    & [data-line-type="change-deletion"] {
      &[data-column-number] {
        &:before {
          background-image: linear-gradient(0deg,
            var(--diffs-bg-deletion) 50%,
            var(--diffs-deletion-base) 50%);
          background-repeat: repeat;
          background-size: 2px 2px;
          background-size: calc(1lh / round(1lh / 2px))
            calc(1lh / round(1lh / 2px));
        }
      }
    }

    & [data-line-type="change-addition"] {
      &[data-column-number] {
        &:before {
          background-color: var(--diffs-addition-base);
        }
      }
    }
  }

  [data-overflow="wrap"] {
    & [data-line] {
      white-space: pre-wrap;
      word-break: break-word;
    }

    & [data-annotation-content] {
      word-break: break-word;
    }
  }

  [data-overflow="scroll"] [data-line] {
    white-space: pre;
    min-height: 1lh;
  }

  [data-column-number] {
    box-sizing: content-box;
    text-align: right;
    user-select: none;
    color: var(--diffs-fg-number);
    padding-left: 2ch;
  }

  [data-line-number-content] {
    min-width: var(--diffs-min-number-column-width, var(--diffs-min-number-column-width-default, 3ch));
    z-index: 1;
    display: inline-block;
    position: relative;
  }

  [data-disable-line-numbers] {
    & [data-gutter-buffer], & [data-column-number] {
      min-width: 4px;
      padding: 0;

      &:before {
        min-width: 0;
      }
    }

    & [data-line-number-content] {
      display: none;
    }

    & [data-gutter-utility-slot] {
      right: unset;
      justify-content: flex-start;
      left: 0;
    }

    &[data-indicators="bars"] [data-gutter-utility-slot] {
      left: 6px;
    }
  }

  [data-file][data-disable-line-numbers] {
    & [data-gutter-buffer], & [data-column-number] {
      border-right: 0;
      min-width: 0;
    }
  }

  [data-diff-span] {
    box-decoration-break: clone;
    border-radius: 3px;
  }

  [data-line-type="change-addition"] [data-diff-span] {
    background-color: var(--diffs-bg-addition-emphasis);
  }

  [data-line-type="change-deletion"] [data-diff-span] {
    background-color: var(--diffs-bg-deletion-emphasis);
  }

  [data-merge-conflict="marker-start"], [data-merge-conflict="marker-base"], [data-merge-conflict="marker-separator"], [data-merge-conflict="marker-end"] {
    color: var(--diffs-fg);
    padding-left: 1ch;
  }

  [data-merge-conflict="marker-start"], [data-merge-conflict="marker-end"] {
    align-items: center;
    display: flex;

    &:after {
      color: var(--diffs-fg-conflict-marker);
      font-size: .75rem;
      font-style: normal;
      line-height: 1.25rem;
      font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));
      padding-left: 1ch;
    }
  }

  [data-merge-conflict="marker-start"]:after {
    content: "(Current Change)";
  }

  [data-merge-conflict="marker-end"]:after {
    content: "(Incoming Change)";
  }

  [data-merge-conflict-actions-content] {
    min-height: 1.75rem;
    font-family: var(--diffs-header-font-family, var(--diffs-header-font-fallback));
    color: var(--diffs-fg);
    align-items: center;
    gap: .25rem;
    padding-inline: .5rem;
    font-size: .75rem;
    line-height: 1.2;
    display: flex;
  }

  [data-merge-conflict-action] {
    appearance: none;
    color: var(--diffs-fg-number);
    font: inherit;
    cursor: pointer;
    background: none;
    border: 0;
    padding: 0;
    font-style: normal;
  }

  [data-merge-conflict-action]:hover {
    color: var(--diffs-fg);
  }

  [data-merge-conflict-action="current"]:hover {
    color: var(--diffs-addition-base);
  }

  [data-merge-conflict-action="incoming"]:hover {
    color: var(--diffs-modified-base);
  }

  [data-merge-conflict-action-separator] {
    color: var(--diffs-fg-number);
    opacity: .6;
    user-select: none;
  }

  [data-diffs-header="default"] {
    background-color: var(--diffs-bg);
    justify-content: space-between;
    align-items: center;
    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));
    min-height: calc(1lh + (var(--diffs-gap-block, var(--diffs-gap-fallback)) * 3));
    z-index: 2;
    flex-direction: row;
    padding-inline: 16px;
    display: flex;
    position: relative;
    top: 0;
  }

  [data-header-content] {
    align-items: center;
    gap: var(--diffs-gap-inline, var(--diffs-gap-fallback));
    white-space: nowrap;
    flex-direction: row;
    min-width: 0;
    display: flex;
  }

  [data-header-content] [data-prev-name], [data-header-content] [data-title] {
    text-overflow: ellipsis;
    white-space: nowrap;
    direction: rtl;
    min-width: 0;
    overflow: hidden;
  }

  [data-prev-name] {
    opacity: .7;
  }

  [data-rename-icon] {
    fill: currentColor;
    flex-grow: 0;
    flex-shrink: 0;
  }

  [data-diffs-header="default"] [data-metadata] {
    white-space: nowrap;
    align-items: center;
    gap: 1ch;
    display: flex;
  }

  [data-diffs-header="default"] [data-additions-count] {
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
    color: var(--diffs-addition-base);
  }

  [data-diffs-header="default"] [data-deletions-count] {
    font-family: var(--diffs-font-family, var(--diffs-font-fallback));
    color: var(--diffs-deletion-base);
  }

  [data-change-icon] {
    fill: currentColor;
    flex-shrink: 0;
  }

  [data-change-icon="change"], [data-change-icon="rename-pure"], [data-change-icon="rename-changed"] {
    color: var(--diffs-modified-base);
  }

  [data-change-icon="new"] {
    color: var(--diffs-addition-base);
  }

  [data-change-icon="deleted"] {
    color: var(--diffs-deletion-base);
  }

  [data-change-icon="file"] {
    opacity: .6;
  }

  [data-annotation-content] {
    z-index: 2;
    isolation: isolate;
    white-space: normal;
    align-self: flex-start;
    min-width: 0;
    display: flow-root;
    position: relative;
  }

  [data-overflow="scroll"] [data-annotation-content], [data-overflow="scroll"] [data-merge-conflict-actions-content] {
    width: var(--diffs-column-content-width, auto);
    left: var(--diffs-column-number-width, 0);
    position: sticky;
  }

  [data-annotation-slot] {
    text-wrap-mode: wrap;
    word-break: normal;
    white-space-collapse: collapse;
  }

  [data-gutter-utility-slot] {
    touch-action: none;
    justify-content: flex-end;
    display: flex;
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
  }

  [data-utility-button] {
    appearance: none;
    cursor: pointer;
    width: 1lh;
    height: 1lh;
    font-size: var(--diffs-font-size, 13px);
    line-height: var(--diffs-line-height, 20px);
    background-color: var(--diffs-modified-base);
    color: var(--diffs-bg);
    fill: currentColor;
    z-index: 4;
    touch-action: none;
    border: none;
    border-radius: 4px;
    justify-content: center;
    align-items: center;
    margin-right: calc(-1lh + 1ch);
    padding: 0;
    display: flex;
    position: relative;

    &:before {
      content: "";
      display: block;
      position: absolute;
      inset: 0 0 0 -4px;
    }
  }

  [data-decoration-bar-stack] {
    pointer-events: none;
    isolation: isolate;
    z-index: 1;
    background-color: var(--diffs-decoration-bar-color, transparent);
    box-sizing: content-box;
    border-left: 2px solid var(--diffs-bg);
    border-right: 2px solid var(--diffs-bg);
    width: 6px;
    position: absolute;
    top: 0;
    bottom: 0;
    right: -2px;

    [data-decoration-bar-depth="1"] & {
      background-color: color-mix(in lab,
        var(--diffs-bg) 20%,
        var(--diffs-decoration-bar-color, transparent));
    }

    [data-decoration-bar-depth="2"] & {
      background-color: color-mix(in lab,
        var(--diffs-bg) 45%,
        var(--diffs-decoration-bar-color, transparent));
    }

    [data-decoration-bar-depth="3"] & {
      background-color: color-mix(in lab,
        var(--diffs-bg) 65%,
        var(--diffs-decoration-bar-color, transparent));
    }

    [data-decoration-bar-start] & {
      border-top-left-radius: 5px;
      border-top-right-radius: 5px;
    }

    [data-decoration-bar-end] & {
      z-index: 3;
      border-bottom-right-radius: 5px;
      border-bottom-left-radius: 5px;
    }
  }

  [data-placeholder] {
    contain: strict;
  }

  [data-error-wrapper] {
    padding: var(--diffs-gap-block, var(--diffs-gap-fallback))
      var(--diffs-gap-inline, var(--diffs-gap-fallback));
    scrollbar-width: none;
    max-height: 400px;
    overflow: auto;

    & [data-error-message] {
      color: var(--diffs-deletion-base);
      font-size: 18px;
      font-weight: bold;
    }

    & [data-error-stack] {
      color: var(--diffs-fg-number);
    }
  }
}

@layer theme, rendered, unsafe;
`,Y=`@layer base, theme, rendered, unsafe;`,tt=RegExp(`${ot(p)}\\s*:\\s*[^;]+;`);function nt(e){return`${Y}
${et}
@layer theme {
  ${e}
}`}function rt(e){return`${Y}
@layer unsafe {
  ${e}
}`}function it(e,t=`system`,n){return`${Y}
@layer rendered {
  :host {${t===`system`?``:`
  color-scheme: ${t};`}
  ${$e(n)}
  ${e}
  }
}`}function at(e,t){let n=$e(t);return e.replace(tt,n)}function ot(e){return e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`)}function st(e){return e?.useTokenTransformer===!0||e?.onTokenClick!=null||e?.onTokenEnter!=null||e?.onTokenLeave!=null}function ct({code:e,pre:t,columnType:n,rowSpan:r,containerSize:i=!1}={}){return e??(e=document.createElement(`code`),e.setAttribute(`data-code`,``),n!=null&&e.setAttribute(`data-${n}`,``),t?.appendChild(e)),r==null?e.style.removeProperty(`grid-row`):e.style.setProperty(`grid-row`,`span ${r}`),i?e.setAttribute(`data-container-size`,``):e.removeAttribute(`data-container-size`),e}function lt(e,t){let n=e?.offsetHeight??0;if(e==null||n===0){t();return}e.style.minHeight=`${n}px`;try{t(),e.offsetHeight}finally{e.style.minHeight=``}}function ut({shadowRoot:e,currentNode:t,themeCSS:n}){if(n.trim()===``){t?.remove();return}return t??=dt(),t.textContent=n,t.parentNode!==e&&e.appendChild(t),t}function dt(){let e=document.createElement(`style`);return e.setAttribute(o,``),e}var ft=void 0;function pt(){return ft??=`safari`in window&&`pushNotification`in window.safari||/^((?!chrome|android).)*safari/i.test(navigator.userAgent)}function mt(e,t){if(t==null)return;let n=e.shadowRoot??e.attachShadow({mode:`open`});n.innerHTML===``&&(n.innerHTML=t)}function ht(e,{type:t,diffIndicators:n,disableBackground:r,disableLineNumbers:i,overflow:a,split:o,totalLines:s,customProperties:c}){if(c!=null)for(let t in c){let n=c[t];n!=null&&e.setAttribute(t,`${n}`)}switch(t===`diff`?(e.setAttribute(`data-diff`,``),e.removeAttribute(`data-file`)):(e.setAttribute(`data-file`,``),e.removeAttribute(`data-diff`)),n){case`bars`:case`classic`:e.setAttribute(`data-indicators`,n);break;case`none`:e.removeAttribute(`data-indicators`)}return i?e.setAttribute(`data-disable-line-numbers`,``):e.removeAttribute(`data-disable-line-numbers`),r?e.removeAttribute(`data-background`):e.setAttribute(`data-background`,``),t===`diff`?e.setAttribute(`data-diff-type`,o?`split`:`single`):e.removeAttribute(`data-diff-type`),e.setAttribute(`data-overflow`,a),e.style.setProperty(`--diffs-min-number-column-width-default`,`${`${s}`.length}ch`),e}if(typeof HTMLElement<`u`&&customElements.get(`diffs-container`)==null){let e;class t extends HTMLElement{constructor(){if(super(),this.shadowRoot!=null)return;let t=this.attachShadow({mode:`open`});e??(e=new CSSStyleSheet,e.replaceSync(et)),t.adoptedStyleSheets=[e]}connectedCallback(){Qe(this.shadowRoot??this.attachShadow({mode:`open`}))}}customElements.define(f,t)}function gt(e,t){return typeof window>`u`&&t!=null?(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(`template`,{shadowrootmode:`open`,dangerouslySetInnerHTML:{__html:t}}),e]}):(0,C.jsx)(C.Fragment,{children:e})}function _t(e,t){return e==null||t==null?e===t:e.top===t.top&&e.bottom===t.bottom}var vt=1e3,yt=vt*4,bt=[0,1e-6,.99999,1],xt={overscrollSize:vt,intersectionObserverMargin:yt,resizeDebugging:!1},X=0,St=-1,Ct=class e{static __STOP=!1;static __lastScrollPosition=0;__id=`virtualizer-${++St}`;config;type=`simple`;intersectionObserver;scrollTop=0;height=0;scrollHeight=0;windowSpecs={top:0,bottom:0};root;contentContainer;resizeObserver;observers=new Map;visibleInstances=new Map;visibleInstancesDirty=!1;instancesChanged=new Set;reconcileQueue=new Set;scrollDirty=!0;heightDirty=!0;scrollHeightDirty=!0;renderedObservers=0;connectQueue=new Map;constructor(e){this.config={...xt,...e}}setup(t,n){if(this.root==null){this.root=t,this.resizeObserver=new ResizeObserver(this.handleContainerResize),this.intersectionObserver=new IntersectionObserver(this.handleIntersectionChange,{root:this.root,threshold:bt,rootMargin:`${this.config.intersectionObserverMargin}px 0px ${this.config.intersectionObserverMargin}px 0px`}),t instanceof Document?this.setupWindow():this.setupElement(n),window.__INSTANCE=this,window.__TOGGLE=()=>{e.__STOP?(e.__STOP=!1,(this.getScrollContainerElement()??window).scrollTo({top:e.__lastScrollPosition}),k(this.computeRenderRangeAndEmit)):(e.__lastScrollPosition=this.getScrollTop(),e.__STOP=!0)};for(let[e,t]of this.connectQueue.entries())this.connect(e,t);this.connectQueue.clear(),this.markDOMDirty(),k(this.computeRenderRangeAndEmit)}}instanceChanged(e,t){this.instancesChanged.add(e),t&&this.markDOMDirty(),k(this.computeRenderRangeAndEmit)}requestHeightReconcile(e){this.reconcileQueue.add(e),k(this.computeRenderRangeAndEmit)}getWindowSpecs(){return this.windowSpecs.top===0&&this.windowSpecs.bottom===0&&(this.windowSpecs=M({scrollTop:this.getScrollTop(),height:this.getHeight(),scrollHeight:this.getScrollHeight(),overscrollSize:this.config.overscrollSize})),this.windowSpecs}getRoot(){return this.root}isInstanceVisible(e,t){let n=this.getScrollTop(),r=this.getHeight(),i=this.config.intersectionObserverMargin,a=n-i,o=n+r+i;return!(e<a-t||e>o)}handleContainerResize=e=>{if(this.root==null)return;let t=!1;for(let n of e){let e=n.borderBoxSize[0].blockSize;this.root instanceof Document?e!==this.scrollHeight&&(this.scrollHeightDirty=!0,t=!0,this.config.resizeDebugging&&(console.log(`Virtualizer: content size change`,this.__id,{sizeChange:e-X,newSize:e}),X=e)):n.target===this.root?e!==this.height&&(this.heightDirty=!0,t=!0):n.target===this.contentContainer&&(this.scrollHeightDirty=!0,t=!0,this.config.resizeDebugging&&(console.log(`Virtualizer: scroller size change`,this.__id,{sizeChange:e-X,newSize:e}),X=e))}t&&k(this.computeRenderRangeAndEmit)};setupWindow(){if(this.root==null||!(this.root instanceof Document))throw Error(`Virtualizer.setupWindow: Invalid setup method`);window.addEventListener(`scroll`,this.handleWindowScroll,{passive:!0}),window.addEventListener(`resize`,this.handleWindowResize,{passive:!0}),this.resizeObserver?.observe(this.root.documentElement)}setupElement(e){if(this.root==null||this.root instanceof Document)throw Error(`Virtualizer.setupElement: Invalid setup method`);this.root.addEventListener(`scroll`,this.handleElementScroll,{passive:!0}),this.resizeObserver?.observe(this.root),e??=this.root.firstElementChild??void 0,e instanceof HTMLElement&&(this.contentContainer=e,this.resizeObserver?.observe(e))}cleanUp(){A(this.computeRenderRangeAndEmit),this.resizeObserver?.disconnect(),this.resizeObserver=void 0,this.intersectionObserver?.disconnect(),this.intersectionObserver=void 0,this.root?.removeEventListener(`scroll`,this.handleElementScroll),window.removeEventListener(`scroll`,this.handleWindowScroll),window.removeEventListener(`resize`,this.handleWindowResize),this.root=void 0,this.contentContainer=void 0,this.observers.clear(),this.visibleInstances.clear(),this.instancesChanged.clear(),this.reconcileQueue.clear(),this.connectQueue.clear(),this.visibleInstancesDirty=!1,this.windowSpecs={top:0,bottom:0},this.scrollTop=0,this.height=0,this.scrollHeight=0,this.scrollDirty=!0,this.heightDirty=!0,this.scrollHeightDirty=!0}getOffsetInScrollContainer(e){return this.getScrollTop()+Z(e,this.getScrollContainerElement())}connect(e,t){if(this.observers.has(e))throw Error(`Virtualizer.connect: instance is already connected...`);return this.intersectionObserver==null?this.connectQueue.set(e,t):(this.intersectionObserver.observe(e),this.observers.set(e,t),this.instancesChanged.add(t),this.markDOMDirty(),k(this.computeRenderRangeAndEmit)),()=>this.disconnect(e)}disconnect(e){let t=this.observers.get(e);this.connectQueue.delete(e),t!=null&&(this.intersectionObserver?.unobserve(e),this.observers.delete(e),this.instancesChanged.delete(t),this.reconcileQueue.delete(t),this.visibleInstances.delete(e)&&(this.visibleInstancesDirty=!0),this.markDOMDirty(),k(this.computeRenderRangeAndEmit))}handleWindowResize=()=>{e.__STOP||window.innerHeight===this.height||(this.heightDirty=!0,k(this.computeRenderRangeAndEmit))};handleWindowScroll=()=>{e.__STOP||this.root==null||!(this.root instanceof Document)||(this.scrollDirty=!0,k(this.computeRenderRangeAndEmit))};handleElementScroll=()=>{e.__STOP||this.root==null||this.root instanceof Document||(this.scrollDirty=!0,k(this.computeRenderRangeAndEmit))};computeRenderRangeAndEmit=()=>{if(e.__STOP)return;let t=this.heightDirty||this.scrollHeightDirty,n=this.instancesChanged.size>0;if(this.instancesChanged.size===0){let e=M({scrollTop:this.getScrollTop(),height:this.getHeight(),scrollHeight:this.getScrollHeight(),overscrollSize:this.config.overscrollSize});if(!t&&_t(this.windowSpecs,e)&&this.renderedObservers===this.observers.size&&!this.visibleInstancesDirty&&this.reconcileQueue.size===0)return;this.windowSpecs=e}this.visibleInstancesDirty=!1,this.renderedObservers=this.observers.size;let r=this.getScrollAnchor(this.height),i=new Set;for(let e of t?this.observers.values():this.visibleInstances.values())e.onRender(t)&&i.add(e);for(let e of this.instancesChanged)i.has(e)||e.onRender(t)&&i.add(e);this.scrollFix(r);for(let e of i)this.reconcileQueue.delete(e),e.reconcileHeights();for(let e of this.reconcileQueue)e.reconcileHeights()&&(n=!0);this.reconcileQueue.clear(),n||=this.instancesChanged.size>0,n&&this.markDOMDirty(),(n||t)&&k(this.computeRenderRangeAndEmit),i.clear(),this.instancesChanged.clear()};scrollFix(e){if(e==null)return;let t=this.getScrollContainerElement(),{lineIndex:n,lineOffset:r,fileElement:i,fileOffset:a,fileTypeOffset:o}=e;if(n!=null&&r!=null){let e=i.shadowRoot?.querySelector(`[data-line][data-line-index="${n}"]`);if(e instanceof HTMLElement){let n=Z(e,t);if(n!==r){let e=n-r;this.applyScrollFix(e)}return}}let s=Z(i,t);if(o===`top`)s!==a&&this.applyScrollFix(s-a);else{let e=s+i.getBoundingClientRect().height;e!==a&&this.applyScrollFix(e-a)}}applyScrollFix(e){this.root==null||this.root instanceof Document?window.scrollTo({top:window.scrollY+e,behavior:`instant`}):this.root.scrollTo({top:this.root.scrollTop+e,behavior:`instant`}),this.markDOMDirty()}getScrollAnchor(e){let t=this.getScrollContainerElement(),n;for(let[r]of this.visibleInstances.entries()){let i=Z(r,t),a=i+r.offsetHeight,o,s;a<=0?(o=a,s=`bottom`):(o=i,s=`top`);let c,l;if(a>0&&i<e)for(let e of r.shadowRoot?.querySelectorAll(`[data-line][data-line-index]`)??[]){if(!(e instanceof HTMLElement))continue;let n=e.dataset.lineIndex;if(n==null)continue;let r=Z(e,t);if(!(r<0)){c=n,l=r;break}}if(n?.lineOffset!=null&&l==null)continue;let u=!1;(n==null||l!=null&&(n.lineOffset==null||l<n.lineOffset)||l==null&&n.lineOffset==null&&(o>=0&&(n.fileOffset<0||o<n.fileOffset)||o<0&&n.fileOffset<0&&o>n.fileOffset))&&(u=!0),u&&(n={fileElement:r,fileTypeOffset:s,fileOffset:o,lineIndex:c,lineOffset:l})}return n}handleIntersectionChange=e=>{this.scrollDirty=!0;for(let{target:t,isIntersecting:n}of e){if(!(t instanceof HTMLElement))throw Error(`Virtualizer.handleIntersectionChange: target not an HTMLElement`);let e=this.observers.get(t);e!=null&&(n&&!this.visibleInstances.has(t)?(e.setVisibility(!0),this.visibleInstances.set(t,e),this.visibleInstancesDirty=!0):!n&&this.visibleInstances.has(t)&&(e.setVisibility(!1),this.visibleInstances.delete(t),this.visibleInstancesDirty=!0))}this.visibleInstancesDirty&&k(this.computeRenderRangeAndEmit)};getScrollTop(){if(!this.scrollDirty)return this.scrollTop;this.scrollDirty=!1;let e=this.root==null?0:this.root instanceof Document?window.scrollY:this.root.scrollTop;return e=this.clampScrollTop(e),this.scrollTop=e,e}scrollTo({top:e,behavior:t=`auto`}){let{root:n}=this;if(n==null)return;let r=this.clampScrollTop(e);n instanceof Document?window.scrollTo({top:r,behavior:t}):n.scrollTo({top:r,behavior:t}),this.scrollDirty=!0,k(this.computeRenderRangeAndEmit)}clampScrollTop(e){return Math.max(0,Math.min(e,this.getScrollHeight()-this.getHeight()))}getScrollHeight(){return this.scrollHeightDirty?(this.scrollHeightDirty=!1,this.scrollHeight=this.root==null?0:this.root instanceof Document?this.root.documentElement.scrollHeight:this.root.scrollHeight,this.scrollHeight):this.scrollHeight}getHeight(){return this.heightDirty?(this.heightDirty=!1,this.height=this.root==null?0:this.root instanceof Document?globalThis.innerHeight:this.root.getBoundingClientRect().height,this.height):this.height}markDOMDirty(){this.scrollDirty=!0,this.scrollHeightDirty=!0,this.heightDirty=!0}getScrollContainerElement(){return this.root==null||this.root instanceof Document?void 0:this.root}};function Z(e,t){let n=e.getBoundingClientRect(),r=t?.getBoundingClientRect().top??0;return n.top-r}var Q=(0,S.createContext)(void 0);function wt({children:e,config:t,className:n,style:r,contentClassName:i,contentStyle:a}){let[o]=(0,S.useState)(()=>typeof window<`u`?new Ct(t):void 0),s=(0,S.useCallback)(e=>{e==null?o?.cleanUp():o?.setup(e)},[o]);return(0,C.jsx)(Q.Provider,{value:o,children:(0,C.jsx)(`div`,{className:n,style:r,ref:s,children:(0,C.jsx)(`div`,{className:i,style:a,children:e})})})}function Tt(){return(0,S.useContext)(Q)}var $=r();function Et(e){let t=(0,$.c)(3),{children:n}=e,r=(0,S.useContext)(i);if(r===null)return n;let a;return t[0]!==n||t[1]!==r.pool?(a=(0,C.jsx)(w.Provider,{value:r.pool,children:n}),t[0]=n,t[1]=r.pool,t[2]=a):a=t[2],a}function Dt(e){(0,$.c)(3);let t;bb0:{t=e;break bb0}return t}export{w as $,q as A,N as B,Ye as C,He as D,We as E,Pe as F,de as G,me as H,Ne as I,le as J,M as K,De as L,Le as M,Ie as N,Ue as O,Fe as P,T as Q,_e as R,Xe as S,Ge as T,pe as U,fe as V,he as W,k as X,A as Y,ce as Z,nt as _,Tt as a,te as at,Qe as b,gt as c,pt as d,se as et,ut as f,at as g,st as h,Q as i,re as it,Re as j,ze as k,ht as l,ct as m,Et as n,ae as nt,Ct as o,lt as p,j as q,wt as r,oe as rt,_t as s,Dt as t,ie as tt,mt as u,it as v,Ke as w,Ze as x,rt as y,ve as z};